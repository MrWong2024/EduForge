from checks import require, equal_text
from learning_task import LearningTask
from submission_record import SubmissionRecord


task = LearningTask("T-A", "条件练习")
first = SubmissionRecord("T-A", "S-1", "初稿")
second = SubmissionRecord("T-A", "S-1", "修订稿")
require(task.receive(first), "接收初稿")
earlier = task.get_history()
require(task.receive(second), "接收修订稿")
require(len(earlier) == 1, "旧名单仍只有一条")
require(earlier[0] is first, "旧名单仍保留原记录")
require(len(task.get_history()) == 2, "当前历史有两条")
require(task.get_history()[1] is second, "修订稿保留在末尾")
print("旧快照检查通过")
