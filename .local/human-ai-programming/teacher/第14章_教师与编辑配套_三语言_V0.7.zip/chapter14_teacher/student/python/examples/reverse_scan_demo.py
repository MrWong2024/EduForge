minutes = [15, 40, 30, 55, 20]
for i in range(len(minutes) - 1, -1, -1):
    print(str(i) + ":" + str(minutes[i]))
