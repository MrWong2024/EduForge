def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def equal_text(expected: str, actual: str, message: str) -> None:
    require(expected == actual, message
            + "；预期=[" + expected + "]；实际=[" + actual + "]")
