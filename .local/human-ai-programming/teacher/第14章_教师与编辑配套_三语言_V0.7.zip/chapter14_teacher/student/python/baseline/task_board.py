class TaskBoard:
    def __init__(self):
        self._by_id = {}

    def register_task(self, task) -> bool:
        task_id = task.get_task_id()
        if task_id in self._by_id:
            return False
        self._by_id[task_id] = task
        return True

    def find(self, task_id: str):
        return self._by_id.get(task_id)

    def list_tasks(self):
        return tuple(self._by_id.values())
