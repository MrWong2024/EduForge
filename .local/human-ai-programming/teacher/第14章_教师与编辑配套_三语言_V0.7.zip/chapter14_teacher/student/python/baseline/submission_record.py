class SubmissionRecord:
    def __init__(self, task_id: str, student_id: str, content: str):
        self._task_id = task_id
        self._student_id = student_id
        self._content = content

    def get_task_id(self) -> str:
        return self._task_id

    def get_student_id(self) -> str:
        return self._student_id

    def get_content(self) -> str:
        return self._content
