from checks import require, equal_text
from learning_task import LearningTask
from submission_record import SubmissionRecord


empty = LearningTask("E", "空历史")
require(empty.find_latest_by_student("S-1") is None, "空历史没有匹配项")
task = LearningTask("T-A", "条件练习")
a1 = SubmissionRecord("T-A", "S-1", "初稿")
b1 = SubmissionRecord("T-A", "S-2", "初稿")
a2 = SubmissionRecord("T-A", "S-1", "修订稿")
b2 = SubmissionRecord("T-A", "S-2", "补充")
require(task.receive(a1), "接收a1")
require(task.receive(b1), "接收b1")
require(task.receive(a2), "接收a2")
require(task.receive(b2), "接收b2")

before = task.get_history()
before_values = []
for record in before:
    before_values.append((record.get_task_id(), record.get_student_id(),
                          record.get_content()))
require(task.find_latest_by_student("S-1") is a2, "S-1最近应为a2")
require(task.find_latest_by_student("S-2") is b2, "S-2最近应为b2")
require(task.find_latest_by_student("S-9") is None, "不存在的学生返回None")
require(task.find_latest_by_student("".join(["S-", "1"])) is a2,
        "比较文字而非身份")
require(task.find_latest_by_student("s-1") is None, "不忽略大小写")
require(task.find_latest_by_student(" S-1 ") is None, "不自动去空格")
after = task.get_history()
require(len(after) == len(before), "查询不改变历史条数")
for i in range(len(before)):
    require(after[i] is before[i], "原记录与次序保持")
    require(before_values[i] == (after[i].get_task_id(),
                                after[i].get_student_id(),
                                after[i].get_content()), "原记录文字保持")
require(task.is_open(), "查询不关闭任务")
equal_text("T-A", task.get_task_id(), "保留编号")
equal_text("条件练习", task.get_title(), "保留标题")
rejected = SubmissionRecord("T-B", "S-1", "不能算最近")
require(not task.receive(rejected), "错误归属被拒绝")
require(task.find_latest_by_student("S-1") is a2, "拒收不参与查询")
task.close()
require(task.find_latest_by_student("S-1") is a2, "关闭后仍能查询")
require(not task.receive(SubmissionRecord("T-A", "S-1", "关闭后尝试")),
        "不放宽关闭规则")
require(task.find_latest_by_student("S-1") is a2, "失败尝试不变成最新")
require(not task.is_open(), "查询不重新开放任务")
require(len(task.get_history()) == 4, "旧历史仍为四条")
print("新查询检查通过")
