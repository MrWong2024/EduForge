from checks import require, equal_text
from learning_task import LearningTask
from submission_record import SubmissionRecord

task = LearningTask("T-A", "条件练习")
a1 = SubmissionRecord("T-A", "S-1", "初稿")
b1 = SubmissionRecord("T-A", "S-2", "初稿")
a2 = SubmissionRecord("T-A", "S-1", "修订稿")
b2 = SubmissionRecord("T-A", "S-2", "补充")
require(task.receive(a1), "接收a1")
require(task.receive(b1), "接收b1")
require(task.receive(a2), "接收a2")
require(task.receive(b2), "接收b2")

found = task.find_latest_by_student("S-1")
require(found is not None, "S-1应有结果")
print(found.get_content())
print(found is a2)
print(len(task.get_history()))
print(task.find_latest_by_student("S-9") is None)
