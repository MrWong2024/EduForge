from checks import require, equal_text
from learning_task import LearningTask
from submission_record import SubmissionRecord


task = LearningTask("T-A", "条件练习")
require(task.receive(SubmissionRecord("T-A", "S-1", "初稿")), "接收初稿")
saved = task.find_latest_by_student("S-1")
require(saved is not None, "先前应找到初稿")
require(task.receive(SubmissionRecord("T-A", "S-1", "修订稿")), "接收修订稿")
now = task.find_latest_by_student("S-1")
require(now is not None, "现在应有结果")
print(saved.get_content())
print(now.get_content())
print(len(task.get_history()))
