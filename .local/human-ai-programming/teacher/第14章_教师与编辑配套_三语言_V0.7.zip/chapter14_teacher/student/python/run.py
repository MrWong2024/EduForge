"""本包薄入口：选择一个阶段，避免把同名模块混在同一次运行中。"""
from pathlib import Path
import runpy
import sys

root = Path(__file__).resolve().parent
entries = {
    "work": {"baseline_checks", "latest_demo", "latest_checks", "query_again_demo"},
    "review": {"baseline_checks", "latest_demo", "latest_checks", "query_again_demo"},
    "examples": {"reverse_scan_demo", "old_snapshot_check"},
    "optional": {"restore_latest_demo"},
}
if len(sys.argv) != 3 or sys.argv[1] not in entries:
    raise SystemExit("用法：python run.py work|review|examples|optional 入口名")
stage, entry = sys.argv[1:]
if entry not in entries[stage]:
    raise SystemExit("没有这个入口，请查看README。")
folder = "review/first_match" if stage == "review" else stage
support = folder if stage in ("work", "review") else "work"
sys.path[:0] = [str(root / support), str(root / folder)]
runpy.run_path(str(root / folder / (entry + ".py")), run_name="__main__")
