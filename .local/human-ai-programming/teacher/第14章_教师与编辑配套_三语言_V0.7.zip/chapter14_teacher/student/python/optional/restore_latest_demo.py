from pathlib import Path
from checks import require
from snapshot_file import load

board = load(Path("optional/samples/good.tasks"))
task = board.find("T-A")
require(task is not None, "应恢复T-A")
found = task.find_latest_by_student("S-1")
require(found is not None, "恢复后应有结果")
print(found.get_content())
print(task.is_open())
print(len(task.get_history()))
