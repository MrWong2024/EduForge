from pathlib import Path
from task_board import TaskBoard
from learning_task import LearningTask
from submission_record import SubmissionRecord
from snapshot_format_error import SnapshotFormatError


def load(path: Path) -> TaskBoard:
    return read_and_close(path.open("r", encoding="utf-8"))


def read_and_close(opened) -> TaskBoard:
    with opened as reader:
        return parse(reader)


def read_line(reader):
    line = reader.readline()
    if line == "":
        return None
    return line.removesuffix("\n")


def problem(line: int, detail: str) -> SnapshotFormatError:
    return SnapshotFormatError("第" + str(line) + "行：" + detail)


def require_text(text: str, line: int):
    if text == "":
        raise problem(line, "文字字段不能为空")


def parse(reader) -> TaskBoard:
    candidate = TaskBoard()
    if read_line(reader) != "TASKS-1":
        raise SnapshotFormatError("第1行应为TASKS-1")
    current_task = None
    close_after_records = False
    line_number = 1
    line = read_line(reader)
    while line is not None:
        line_number = line_number + 1
        if line == "END":
            if current_task is not None and close_after_records:
                current_task.close()
            if read_line(reader) is not None:
                raise SnapshotFormatError("END之后不能再有内容")
            return candidate
        fields = line.split("\t")
        if fields[0] == "TASK":
            if len(fields) != 4:
                raise problem(line_number, "TASK行应有4个字段")
            require_text(fields[1], line_number)
            require_text(fields[2], line_number)
            if fields[3] not in ("OPEN", "CLOSED"):
                raise problem(line_number, "状态只能是OPEN或CLOSED")
            if current_task is not None and close_after_records:
                current_task.close()
            current_task = LearningTask(fields[1], fields[2])
            if not candidate.register_task(current_task):
                raise problem(line_number, "任务编号重复")
            close_after_records = fields[3] == "CLOSED"
        elif fields[0] == "SUBMIT":
            if len(fields) != 3 or current_task is None:
                raise problem(line_number, "SUBMIT行应有3个字段且位于TASK之后")
            require_text(fields[1], line_number)
            require_text(fields[2], line_number)
            record = SubmissionRecord(current_task.get_task_id(), fields[1], fields[2])
            if not current_task.receive(record):
                raise problem(line_number, "历史记录无法恢复")
        else:
            raise problem(line_number, "无法识别的行")
        line = read_line(reader)
    raise SnapshotFormatError("缺少END，文件可能不完整")


def require_writable(text: str):
    if text == "" or any(c in text for c in ("\t", "\n", "\r")):
        raise SnapshotFormatError("TASKS-1文字字段不能为空或含制表符、换行")


def to_lines(board: TaskBoard):
    lines = ["TASKS-1"]
    for task in board.list_tasks():
        require_writable(task.get_task_id())
        require_writable(task.get_title())
        state = "OPEN" if task.is_open() else "CLOSED"
        lines.append("TASK\t" + task.get_task_id() + "\t" + task.get_title() + "\t" + state)
        for record in task.get_history():
            require_writable(record.get_student_id())
            require_writable(record.get_content())
            lines.append("SUBMIT\t" + record.get_student_id() + "\t" + record.get_content())
    lines.append("END")
    return lines


def save_new(path: Path, board: TaskBoard):
    lines = to_lines(board)
    text = "\n".join(lines) + "\n"
    text.encode("utf-8")  # Check encodability before creating a target.
    with path.open("x", encoding="utf-8", newline="\n") as writer:
        writer.write(text)
