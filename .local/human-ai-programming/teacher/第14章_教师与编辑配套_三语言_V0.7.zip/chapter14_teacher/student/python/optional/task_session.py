from pathlib import Path
from task_board import TaskBoard
from snapshot_file import load


class TaskSession:
    def __init__(self, initial: TaskBoard):
        self._current = initial

    def get_current(self) -> TaskBoard:
        return self._current

    def restore(self, path: Path):
        candidate = load(path)
        self._current = candidate
