class SnapshotFormatError(Exception):
    pass
