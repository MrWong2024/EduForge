import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

/** TASKS-1 teaching format. Local, single-threaded, small files only. */
public final class SnapshotFile {
    private SnapshotFile() { }

    public static TaskBoard load(Path path)
            throws IOException, SnapshotFormatException {
        return readAndClose(
                Files.newBufferedReader(path, StandardCharsets.UTF_8));
    }

    // Takes ownership of this reader. Also used by deterministic resource checks.
    static TaskBoard readAndClose(BufferedReader opened)
            throws IOException, SnapshotFormatException {
        try (BufferedReader reader = opened) {
            return parse(reader);
        }
    }

    private static TaskBoard parse(BufferedReader reader)
            throws IOException, SnapshotFormatException {
        TaskBoard candidate = new TaskBoard();
        String first = reader.readLine();
        if (!"TASKS-1".equals(first)) {
            throw new SnapshotFormatException("第1行应为TASKS-1");
        }
        LearningTask currentTask = null;
        boolean closeAfterRecords = false;
        int lineNumber = 1;
        String line = reader.readLine();
        while (line != null) {
            lineNumber = lineNumber + 1;
            if (line.equals("END")) {
                if (currentTask != null && closeAfterRecords) {
                    currentTask.close();
                }
                if (reader.readLine() != null) {
                    throw new SnapshotFormatException("END之后不能再有内容");
                }
                return candidate;
            }
            String[] fields = line.split("\t", -1);
            if (fields[0].equals("TASK")) {
                if (fields.length != 4) {
                    throw problem(lineNumber, "TASK行应有4个字段");
                }
                requireText(fields[1], lineNumber);
                requireText(fields[2], lineNumber);
                if (!fields[3].equals("OPEN") && !fields[3].equals("CLOSED")) {
                    throw problem(lineNumber, "状态只能是OPEN或CLOSED");
                }
                if (currentTask != null && closeAfterRecords) {
                    currentTask.close();
                }
                currentTask = new LearningTask(fields[1], fields[2]);
                if (!candidate.register(currentTask)) {
                    throw problem(lineNumber, "任务编号重复");
                }
                closeAfterRecords = fields[3].equals("CLOSED");
            } else if (fields[0].equals("SUBMIT")) {
                if (fields.length != 3 || currentTask == null) {
                    throw problem(lineNumber, "SUBMIT行应有3个字段且位于TASK之后");
                }
                requireText(fields[1], lineNumber);
                requireText(fields[2], lineNumber);
                SubmissionRecord record = new SubmissionRecord(
                        currentTask.getTaskId(), fields[1], fields[2]);
                if (!currentTask.receive(record)) {
                    throw problem(lineNumber, "历史记录无法恢复");
                }
            } else {
                throw problem(lineNumber, "无法识别的行");
            }
            line = reader.readLine();
        }
        throw new SnapshotFormatException("缺少END，文件可能不完整");
    }

    private static SnapshotFormatException problem(int line, String detail) {
        return new SnapshotFormatException("第" + line + "行：" + detail);
    }

    private static void requireText(String text, int line)
            throws SnapshotFormatException {
        if (text.isEmpty()) {
            throw problem(line, "文字字段不能为空");
        }
    }

    /** Optional export: creates a new file, never overwrites an existing target. */
    public static void saveNew(Path path, TaskBoard board)
            throws IOException, SnapshotFormatException {
        List<String> lines = toLines(board);
        try (BufferedWriter writer = Files.newBufferedWriter(
                path, StandardCharsets.UTF_8,
                StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE)) {
            for (int i = 0; i < lines.size(); i = i + 1) {
                writer.write(lines.get(i));
                writer.write("\n");
            }
        }
    }

    private static List<String> toLines(TaskBoard board)
            throws SnapshotFormatException {
        ArrayList<String> lines = new ArrayList<>();
        lines.add("TASKS-1");
        List<LearningTask> tasks = board.listTasks();
        for (int i = 0; i < tasks.size(); i = i + 1) {
            LearningTask task = tasks.get(i);
            requireWritable(task.getTaskId());
            requireWritable(task.getTitle());
            String state = "OPEN";
            if (!task.isOpen()) {
                state = "CLOSED";
            }
            lines.add("TASK\t" + task.getTaskId() + "\t"
                    + task.getTitle() + "\t" + state);
            List<SubmissionRecord> records = task.getHistory();
            for (int j = 0; j < records.size(); j = j + 1) {
                SubmissionRecord record = records.get(j);
                requireWritable(record.getStudentId());
                requireWritable(record.getContent());
                lines.add("SUBMIT\t" + record.getStudentId()
                        + "\t" + record.getContent());
            }
        }
        lines.add("END");
        return lines;
    }

    private static void requireWritable(String text)
            throws SnapshotFormatException {
        if (text == null || text.isEmpty() || text.indexOf('\t') >= 0
                || text.indexOf('\n') >= 0 || text.indexOf('\r') >= 0) {
            throw new SnapshotFormatException("TASKS-1文字字段不能为空或含制表符、换行");
        }
    }
}
