import java.nio.file.Path;

public class RestoreLatestDemo {
    public static void main(String[] args) throws Exception {
        TaskSession session = new TaskSession(new TaskBoard());
        session.restore(Path.of("optional", "samples", "good.tasks"));
        LearningTask task = session.getCurrent().find("T-A");
        SubmissionRecord latest = task.findLatestByStudent("S-1");
        System.out.println(latest.getContent());
        System.out.println(task.isOpen());
        System.out.println(task.getHistory().size());
    }
}
