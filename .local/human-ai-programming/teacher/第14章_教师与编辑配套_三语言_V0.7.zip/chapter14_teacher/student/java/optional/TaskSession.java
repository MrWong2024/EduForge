import java.io.IOException;
import java.nio.file.Path;

/** Holds the current board; a successful restore replaces only this reference. */
public final class TaskSession {
    private TaskBoard current;

    public TaskSession(TaskBoard initial) {
        current = initial;
    }

    public TaskBoard getCurrent() { return current; }

    public void restore(Path path)
            throws IOException, SnapshotFormatException {
        TaskBoard candidate = SnapshotFile.load(path);
        current = candidate;
    }
}
