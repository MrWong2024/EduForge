public class SnapshotFormatException extends Exception {
    public SnapshotFormatException(String message) {
        super(message);
    }
}
