public class LatestDemo {
    public static void main(String[] args) {
        LearningTask task = new LearningTask("T-A", "条件练习");
        SubmissionRecord a1 = new SubmissionRecord("T-A", "S-1", "初稿");
        SubmissionRecord b1 = new SubmissionRecord("T-A", "S-2", "初稿");
        SubmissionRecord a2 = new SubmissionRecord("T-A", "S-1", "修订稿");
        SubmissionRecord b2 = new SubmissionRecord("T-A", "S-2", "补充");
        task.receive(a1);
        task.receive(b1);
        task.receive(a2);
        task.receive(b2);
        SubmissionRecord found = task.findLatestByStudent("S-1");
        System.out.println(found.getContent());
        System.out.println(found == a2);
        System.out.println(task.getHistory().size());
        System.out.println(task.findLatestByStudent("S-9") == null);
    }
}
