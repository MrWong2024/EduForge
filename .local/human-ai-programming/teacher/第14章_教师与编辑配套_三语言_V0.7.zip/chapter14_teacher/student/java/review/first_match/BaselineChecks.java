import java.util.List;

public class BaselineChecks {
    public static void main(String[] args) {
        LearningTask task = new LearningTask("T-A", "条件练习");
        LearningTask other = new LearningTask("T-B", "循环练习");
        SubmissionRecord first = new SubmissionRecord("T-A", "S-1", "初稿");
        Checks.require(task.isOpen(), "新任务应开放");
        Checks.require(task.receive(first), "第一次应接收");
        List<SubmissionRecord> earlier = task.getHistory();
        Checks.require(task.receive(first), "再次接收同一记录也应追加");
        Checks.require(earlier.size() == 1, "旧快照不随追加改变");
        Checks.require(task.getHistory().size() == 2, "两次接收保留两条");
        Checks.require(task.getHistory().get(0) == first, "首条保留原记录");
        Checks.require(task.getHistory().get(1) == first, "第二条同样保留");
        Checks.require(!other.receive(first), "归属错误应拒绝");
        Checks.require(other.getHistory().isEmpty(), "拒绝后仍无历史");
        task.close();
        task.close();
        Checks.require(!task.isOpen(), "重复关闭不重开");
        Checks.require(other.isOpen(), "另一任务仍开放");
        Checks.require(!task.receive(first), "关闭后不接收");
        Checks.require(task.getHistory().size() == 2, "关闭拒绝不删历史");
        boolean blocked = false;
        try { task.getHistory().clear(); }
        catch (UnsupportedOperationException e) { blocked = true; }
        Checks.require(blocked, "查询不能提供历史写入口");
        TaskBoard board = new TaskBoard();
        Checks.require(board.register(task), "第一次登记成功");
        Checks.require(!board.register(new LearningTask("T-A", "替换")), "重复编号拒绝");
        Checks.require(board.find("T-A") == task, "仍是原任务");
        Checks.require(board.find("missing") == null, "缺失不创建对象");
        System.out.println("原有行为检查通过");
    }
}
