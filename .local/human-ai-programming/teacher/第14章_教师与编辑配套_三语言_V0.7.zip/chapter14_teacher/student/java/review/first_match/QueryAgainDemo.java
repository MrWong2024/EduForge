public class QueryAgainDemo {
    public static void main(String[] args) {
        LearningTask task = new LearningTask("T-A", "条件练习");
        SubmissionRecord first = new SubmissionRecord("T-A", "S-1", "初稿");
        task.receive(first);
        SubmissionRecord saved = task.findLatestByStudent("S-1");
        task.receive(new SubmissionRecord("T-A", "S-1", "修订稿"));
        System.out.println(saved.getContent());
        System.out.println(task.findLatestByStudent("S-1").getContent());
        System.out.println(task.getHistory().size());
    }
}
