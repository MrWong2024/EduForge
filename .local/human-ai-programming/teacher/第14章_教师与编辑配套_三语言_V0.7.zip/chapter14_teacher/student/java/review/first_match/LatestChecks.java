import java.util.List;

public class LatestChecks {
    public static void main(String[] args) {
        LearningTask task = new LearningTask("T-A", "条件练习");
        Checks.require(task.findLatestByStudent("S-1") == null, "空历史没有匹配项");
        SubmissionRecord a1 = new SubmissionRecord("T-A", "S-1", "初稿");
        SubmissionRecord b1 = new SubmissionRecord("T-A", "S-2", "初稿");
        SubmissionRecord a2 = new SubmissionRecord("T-A", "S-1", "修订稿");
        SubmissionRecord b2 = new SubmissionRecord("T-A", "S-2", "补充");
        Checks.require(task.receive(a1), "接收a1");
        Checks.require(task.receive(b1), "接收b1");
        Checks.require(task.receive(a2), "接收a2");
        Checks.require(task.receive(b2), "接收b2");
        List<SubmissionRecord> before = task.getHistory();
        Checks.require(task.findLatestByStudent("S-1") == a2, "S-1最近应为a2");
        Checks.require(task.findLatestByStudent("S-2") == b2, "S-2最近应为b2");
        Checks.require(task.findLatestByStudent("S-9") == null, "不存在的学生返回null");
        Checks.require(
            task.findLatestByStudent(new String("S-1")) == a2,
            "比较文字而非引用");
        Checks.require(task.findLatestByStudent("s-1") == null, "不忽略大小写");
        Checks.require(task.findLatestByStudent(" S-1 ") == null, "不自动去空格");
        List<SubmissionRecord> after = task.getHistory();
        Checks.require(after.size() == before.size(), "查询不改变历史条数");
        for (int i = 0; i < before.size(); i = i + 1) {
            Checks.require(after.get(i) == before.get(i), "原记录与次序保持");
        }
        Checks.require(task.isOpen(), "查询不关闭任务");
        SubmissionRecord rejected = new SubmissionRecord("T-B", "S-1", "不能算最近");
        Checks.require(!task.receive(rejected), "错误归属被拒绝");
        Checks.require(task.findLatestByStudent("S-1") == a2, "拒收不参与查询");
        task.close();
        Checks.require(task.findLatestByStudent("S-1") == a2,
            "关闭后仍能查询");
        Checks.require(!task.receive(
            new SubmissionRecord("T-A", "S-1", "关闭后尝试")),
            "不放宽关闭规则");
        Checks.require(task.findLatestByStudent("S-1") == a2,
            "失败尝试不变成最新");
        Checks.require(!task.isOpen(), "查询不重新开放任务");
        Checks.require(task.getHistory().size() == 4, "旧历史仍为四条");
        System.out.println("新查询检查通过");
    }
}
