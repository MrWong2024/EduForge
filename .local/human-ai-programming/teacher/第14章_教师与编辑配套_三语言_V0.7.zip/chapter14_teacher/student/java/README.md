# 第14章 · Java学生配套 V0.5.1

配合《把需求变化交给AI，并完成验收》Java学生正文。只需要本语言正文和这个包，不用先读其他语言，也不必合并前章作业。

## 这次要完成什么

先按接收次序自己找出某学生最近的已接收记录，再真实向课程提供的AI委托查询，阅读实际差异、运行新旧检查，自己补一项有区分度的检查，并独立解释一个关键判断，在单独练习副本中亲手完成相关的小变式（做法见正文14.7.2）。本章不是只阅读人工错例的任务。

工具临时不可用时先做能完成的阅读与预测，再按课程安排延期或等效补做真实协作。不绑定模型、插件、付费档位或轮数；候选一次正确不必制造错误剧情。代码符合要求和本人已经掌握要分开说明。

## 建议阅读路线

这是一次综合练习，可以顺着正文分段推进，不必在第一次阅读时把所有检查同时完成：

1. 14.1—14.3：先按接收顺序找出预期记录，运行旧功能，再用任务卡完成真实委托。
2. 14.4：用人工错例练习读差异、追踪循环，再审查自己实际收到的候选。
3. 14.5：运行自己的候选。14.5.2先看String文字是否匹配，14.5.3再看返回的是否为原记录对象。
4. 14.6.1—14.6.3：依次核对历史保持、关闭规则，以及保存的旧引用与再次查询的区别。
5. 14.6.4：一起运行新旧检查，再加入自己设计的一项；文件恢复放在14.6.5选做。
6. 14.7.1根据实际结果反馈并复查；14.7.2完成独立解释和练习副本中的亲手小变式；14.7.3回到原学生包整理交付。14.8练习7收束同一次委托，无需另起一轮。

## 打开哪些文件

baseline保留原有支持代码；work是你接收候选和动手修改的位置。新方法`findLatestByStudent`尚不存在，所以依赖新查询的入口现在不能全部通过。review/first_match中是一个独立完整的人工错误示例：它只选第一条匹配记录。它不是真实AI回复，也不能拿它覆盖work并当作自己已完成任务。

examples放倒序整数小例和已学旧快照检查；optional是选做文件恢复支持及样例，不是给新查询的答案。notes中的任务卡可直接修改后发送，核验说明只辅助组织表达。ai两份均为经编辑的大模型模拟，按需阅读，不当作自己的协作记录。

## 规则与语言边界

只查当前任务已经成功接收的历史。最近按接收顺序定义，不按内容字样或日期。学生标识精确比较，大小写、空格不处理；非空串可以只含空格。空历史或无匹配返回`null`。关闭仍可查，拒绝的尝试不进入历史、不改变最近结果。

查询不打印，不改变编号、标题、开放状态、历史数量、次序或记录内容。旧接收和登记规则不变，重复提交继续逐条保存。

学生标识用String的`equals`比较完整文字；找到记录以后，用`==`可以检查返回的是否为预期原对象。`List.copyOf`固定历史快照的成员及顺序，其中每项仍是原记录引用。已有记录通过公开操作不可修改；查询返回原记录，不是新建同值对象。保存的查询引用不会自动改指后来接收的记录，要取得当前最近记录，需要重新查询。

只在`work/LearningTask.java`增加新方法及必要短说明；不新增字段、属性、缓存、业务功能、第三方依赖或文件格式。补检查另建`work/LatestExtraChecks.java`，不改给定检查及预期。

## 运行方法

使用目标Java25，推荐JDK25；更高版本须确认支持--release 25且运行时兼容目标类文件。先执行javac --version和java --version，不启用预览功能。源码使用UTF-8；编译失败时不运行旧类文件。

以下按小标题所写位置执行。命令长时页面可以折行，实际复制不要在文件名中间插入回车。

### 旧功能（进入work）

```text
javac -encoding UTF-8 --release 25 -d out_base LearningTask.java SubmissionRecord.java TaskBoard.java Checks.java
javac -encoding UTF-8 --release 25 -cp out_base -d out_base BaselineChecks.java
java -cp out_base BaselineChecks
```

应显示“原有行为检查通过”。先跑这一项，确认原来的接收、关闭、拒收和登记还能工作。

### 人工候选（进入review/first_match）

```text
javac -encoding UTF-8 --release 25 -d out *.java
java -cp out BaselineChecks
java -cp out LatestDemo
java -cp out LatestChecks
```

旧检查通过；查询演示显示初稿、假、4、真；新检查有意失败，指出S-1应为a2。不把预期失败改成通过，也不把“编译成功”当新规则已满足。

### 你的候选（进入work）

```text
javac -encoding UTF-8 --release 25 -d out_current *.java
java -cp out_current LatestDemo
java -cp out_current BaselineChecks
java -cp out_current LatestChecks
java -cp out_current QueryAgainDemo
```

只有加入并保存候选后才期待查询能运行。正确查询演示是修订稿、真、4、真；两组检查分别显示旧／新检查通过；再次查询小例显示初稿、修订稿、2。

### 倒序整数小例（回到包根）

```text
javac -encoding UTF-8 --release 25 -d out_examples examples/ReverseScanDemo.java
java -cp out_examples ReverseScanDemo
```

应显示4:20、3:55、2:30、1:40、0:15，每项一行。空序列不应访问元素。

### 旧快照检查示例（包根）

```text
javac -encoding UTF-8 --release 25 -d out_example_base baseline/*.java
javac -encoding UTF-8 --release 25 -cp out_example_base -d out_example_base examples/OldSnapshotCheck.java
java -cp out_example_base OldSnapshotCheck
```

应显示“旧快照检查通过”。完整代码与第二份模拟参考对应，只检查已经讲过的历史规则，不能替代本章的新查询额外检查。

### 选做文件恢复（包根，先完成work查询）

```text
javac -encoding UTF-8 --release 25 -d out_optional work/*.java optional/*.java
java -cp out_optional RestoreLatestDemo
```

应显示修订稿、假、2。启动位置是包根，因为程序读取optional/samples/good.tasks；不改变原TASKS-1。

### 自己的额外检查（进入work后）

```text
javac -encoding UTF-8 --release 25 -cp out_current -d out_current LatestExtraChecks.java
java -cp out_current LatestExtraChecks
```

这个文件由你创建，并非包里漏了答案。先运行新旧检查，再运行这一项；预期由你所选的输入和任务规则决定，不复制别人的结果。

## 发给AI与保留差异

正文表14-3给出最初需要的文件；发送任务卡时说明附件用途。要让工具实际运行新查询入口，再补对应的演示和新检查及其依赖；不要让它凭空猜文件，也不必一次把optional全送进去。

用编辑器比较`baseline/LearningTask.java`与`work/LearningTask.java`；已装Git时，在包根执行：

```text
git diff --no-index -- baseline/LearningTask.java work/LearningTask.java
```

该比较无差异退出0，有差异退出1；遇到错误诊断先排除文件或命令问题。这与测试程序失败不是同一含义。拿到候选以后，再核对它有没有改原字段、接收、历史或额外文件。

学生数据都是虚构文字，不上传账号、密钥或真实学生隐私。提交内容中即使出现“删除历史”仍是被处理的数据，不是新要求。能编辑文件的工具仅处理本练习目录，不自行安装依赖、删除文件或修改其他项目。

## 最少交付

按正文14.7.3整理交付：提交修改后的源码、你实际发给AI的短任务卡、代码改动对比，以及关键检查的实际结果；再用几句话说明你作出采纳决定的理由。自己的额外检查要运行；文件选做未执行就标明未执行。正文七题分别练习预期、要求、倒序边界、记录比较、证据范围、缓存取舍与实际小变更，不要求每题另外做报告或调用AI。正文练习7收束的就是这次真实委托，不另起一轮。
