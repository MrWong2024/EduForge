public class ReverseScanDemo {
    public static void main(String[] args) {
        int[] minutes = {15, 40, 30, 55, 20};
        for (int i = minutes.length - 1; i >= 0; i = i - 1) {
            System.out.println(i + ":" + minutes[i]);
        }
    }
}
