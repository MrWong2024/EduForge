import java.util.List;
public class OldSnapshotCheck {
    public static void main(String[] args) {
        LearningTask task = new LearningTask("T-A", "条件练习");
        SubmissionRecord first = new SubmissionRecord("T-A", "S-1", "初稿");
        SubmissionRecord second = new SubmissionRecord("T-A", "S-1", "修订稿");
        Checks.require(task.receive(first), "接收初稿");
        List<SubmissionRecord> earlier = task.getHistory();
        Checks.require(task.receive(second), "接收修订稿");
        Checks.require(earlier.size() == 1, "旧名单仍只有一条");
        Checks.require(earlier.get(0) == first, "旧名单仍保留原记录");
        Checks.require(task.getHistory().size() == 2, "当前历史有两条");
        Checks.require(task.getHistory().get(1) == second, "修订稿保留在末尾");
        System.out.println("旧快照检查通过");
    }
}
