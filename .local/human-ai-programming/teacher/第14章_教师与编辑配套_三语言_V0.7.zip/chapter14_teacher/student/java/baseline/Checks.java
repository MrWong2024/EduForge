public final class Checks {
    private Checks() { }

    public static void require(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    public static void equalText(String expected, String actual,
                                 String message) {
        require(expected.equals(actual), message
                + "；预期=[" + expected + "]；实际=[" + actual + "]");
    }
}
