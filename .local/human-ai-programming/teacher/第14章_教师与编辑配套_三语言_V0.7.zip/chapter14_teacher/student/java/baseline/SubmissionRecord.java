/** Teaching value object. Caller supplies non-null, non-empty strings. */
public final class SubmissionRecord {
    private final String taskId;
    private final String studentId;
    private final String content;

    public SubmissionRecord(String taskId, String studentId,
                            String content) {
        this.taskId = taskId;
        this.studentId = studentId;
        this.content = content;
    }

    public String getTaskId() { return taskId; }
    public String getStudentId() { return studentId; }
    public String getContent() { return content; }
}
