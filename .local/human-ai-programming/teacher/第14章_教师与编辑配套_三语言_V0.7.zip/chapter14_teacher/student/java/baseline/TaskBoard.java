import java.util.LinkedHashMap;
import java.util.List;

public final class TaskBoard {
    private final LinkedHashMap<String, LearningTask> byId =
            new LinkedHashMap<>();

    public TaskBoard() { }

    public boolean register(LearningTask task) {
        String id = task.getTaskId();
        if (byId.containsKey(id)) {
            return false;
        }
        byId.put(id, task);
        return true;
    }

    public LearningTask find(String taskId) {
        return byId.get(taskId);
    }

    public List<LearningTask> listTasks() {
        return List.copyOf(byId.values());
    }
}
