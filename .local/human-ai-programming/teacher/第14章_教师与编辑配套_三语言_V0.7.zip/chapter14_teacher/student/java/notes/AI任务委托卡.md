# AI任务委托卡

这是第14章本语言任务卡的文字版。把附件和运行条件换成你实际使用的内容，不把待执行计划写成结果。

## 目标

为LearningTask增加public SubmissionRecord findLatestByStudent(String studentId)。只查询当前任务的已接收历史，按成功接收顺序选择指定学生最后一条匹配记录；返回那条原记录引用，空历史或无匹配返回null。

## 已知代码

随附work中的LearningTask、SubmissionRecord、BaselineChecks、TaskBoard和Checks。studentId由调用者保证非null且长度大于0；按完整字符串内容精确比较，不去空格、不忽略大小写。本题不处理登录或查询权限。

## 不能改变

关闭任务仍可查询。查询不打印，不改变任务编号、标题、开放状态、历史条数、次序或记录。已有方法保持原行为，同一学生的多次提交继续逐条保留。

## 修改范围

只在work/LearningTask.java增加此方法及必要短说明；不增加字段、依赖、其他业务改动或文件格式改动。需要补检查时另建work/LatestExtraChecks.java，不改写已给的检查和预期。

## 怎样算完成

给出简短思路和实际差异；核对普通查询、无匹配、重复提交、关闭任务及历史保持，再运行新旧检查。列出实际执行的命令与结果；未执行的检查单独说明。只写计划或只给代码，都还不是验证完成。
