"""Chapter14 reproducible checks. No network or external packages.
Default Java release25; --java-release 21 explicitly means compatibility only.
Use --language and --output to write separate immutable execution evidence.
The three ai cases execute snippets extracted from edited reference Markdown;
they are not independent AI calls or evidence of student collaboration.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,platform,re,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent
names={'baseline_checks':'BaselineChecks','latest_demo':'LatestDemo','latest_checks':'LatestChecks','query_again_demo':'QueryAgainDemo','reverse_scan_demo':'ReverseScanDemo','old_snapshot_check':'OldSnapshotCheck','restore_latest_demo':'RestoreLatestDemo','core':'CoreContract'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(cmd,cwd):
 t=now()
 try:
  p=subprocess.run([str(x) for x in cmd],cwd=cwd,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=45,env={**os.environ,'LC_ALL':'C.UTF-8','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1'})
  return {'command':[str(x) for x in cmd],'cwd':str(cwd),'started_utc':t,'finished_utc':now(),'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 except subprocess.TimeoutExpired:
  return {'command':[str(x) for x in cmd],'cwd':str(cwd),'started_utc':t,'finished_utc':now(),'error':'timeout'}
 except OSError as e:
  return {'command':[str(x) for x in cmd],'cwd':str(cwd),'started_utc':t,'finished_utc':now(),'error':str(e),'returncode':None}
def prepare(c,w,release):
 l=c['language'];s=ROOT/'student'/l;teacher=ROOT/'teacher'/l
 shutil.copytree(s,w/'student');root=w/'student';used={str(p.relative_to(ROOT)):sha(p) for p in s.rglob('*') if p.is_file()}
 name='LearningTask.java' if l=='java' else 'learning_task.hpp' if l=='cpp' else 'learning_task.py'
 kind=c['kind'];stage=c['stage'];entry=c['entry'];variant=(teacher/'mutants'/stage if kind=='mutant' else teacher/stage)
 if kind in ['reference_student','teacher','mutant'] or (kind=='git' and stage=='reference'):
  v=variant/name;shutil.copyfile(v,root/'work'/name);used[str(v.relative_to(ROOT))]=sha(v)
 if kind=='git':
  return root,used,None,['git','diff','--no-index','--','baseline/'+name,'work/'+name]
 folder=root/('review/first_match' if stage=='review' else 'examples' if stage=='examples' else 'optional' if entry=='restore_latest_demo' else 'work')
 if kind in ['teacher','mutant']:
  fn=(names.get(entry,entry)+'.java' if l=='java' else {'core':'core_contract','restore':'restore_contract'}.get(entry,entry)+('.cpp' if l=='cpp' else '.py'))
  origin=teacher/'checks'/fn;dest=root/'work'/fn;shutil.copyfile(origin,dest);used[str(origin.relative_to(ROOT))]=sha(origin);folder=root/'work'
 else:
  fn=names[entry]+'.java' if l=='java' else entry+('.cpp' if l=='cpp' else '.py');dest=folder/fn
 if kind=='ai':
  md=s/'ai/02_委托旧行为补查.md';candidate=re.search(r'```'+l+r'\n(.*?)\n```',md.read_text(),re.S).group(1)+'\n'
  if candidate.strip()!=dest.read_text().strip():raise ValueError('AI example differs from executable source')
  dest.write_text(candidate);used[str(md.relative_to(ROOT))]=sha(md)
 support=root/('review/first_match' if stage=='review' else 'baseline' if stage=='examples' else 'work')
 args=c.get('args',[])
 if l=='java':
  sources=[support/x for x in ['LearningTask.java','SubmissionRecord.java','TaskBoard.java','Checks.java']]+[dest]
  if entry in ['restore_latest_demo','RestoreQueryChecks','SnapshotChecks']:
   sources += [root/'optional'/x for x in ['SnapshotFile.java','SnapshotFormatException.java','TaskSession.java']]
  build=['javac','-encoding','UTF-8','--release',str(release),'-d',str(w/'out')]+list(dict.fromkeys(sources))
  cmd=['java','-cp',str(w/'out'),dest.stem]+args
 elif l=='cpp':
  build=['g++','-std=c++23','-Wall','-Wextra','-pedantic','-I'+str(support),'-I'+str(root/'optional'),str(dest),'-o',str(w/'program')]
  cmd=[str(w/'program')]+args
 else:
  build=None
  if kind in ['student','reference_student','ai']:
   step= 'review' if stage=='review' else 'examples' if stage=='examples' else 'optional' if entry=='restore_latest_demo' else 'work'
   cmd=[sys.executable,'run.py',step,entry]
  else:
   cmd=[sys.executable,'-c',f"import sys,runpy;sys.path[:0]=['work','optional'];runpy.run_path({str(dest.relative_to(root))!r},run_name='__main__')"]+args
 staged={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}
 used['_staged_files']=staged
 return root,used,build,cmd
def matches(actual,exp):
 if actual.get('error'):return False
 code=actual.get('returncode');out=actual.get('stdout','');err=actual.get('stderr','')
 if exp['type'] in ['compile_failure','run_failure']:
  return code not in [None,0] and exp['stderr_contains'] in err
 if code!=exp.get('returncode',0):return False
 if 'stdout' in exp and out!=exp['stdout']:return False
 if 'stdout_regex'in exp and not re.fullmatch(exp['stdout_regex'],out):return False
 if any(t not in out for t in exp.get('stdout_contains',[])):return False
 return err==exp.get('stderr','')
def java_target_executed(environment,release):
 # Keep the existing metadata name; individual execution results remain in records.
 def major(result):
  if result.get('returncode')!=0 or result.get('error'):return None
  match=re.search(r'^(?:openjdk|java|javac)(?:\s+version)?\s+"?(\d+)',result.get('stdout','')+'\n'+result.get('stderr',''),re.M)
  return int(match.group(1)) if match else None
 runtime=major(environment['java']);compiler=major(environment['javac'])
 return release==25 and runtime is not None and runtime>=25 and compiler is not None and compiler>=25

def main():
 p=argparse.ArgumentParser();p.add_argument('--language',choices=['java','cpp','python','all'],default='all');p.add_argument('--java-release',type=int,default=25);p.add_argument('--output',help='新执行记录路径；默认写入本包output目录');a=p.parse_args()
 cases=json.loads((ROOT/'cases.json').read_text())['cases'];cases=[c for c in cases if a.language=='all' or c['language']==a.language]
 if not cases:p.error('没有符合所选语言的用例。')
 languages={c['language'] for c in cases};program_languages={c['language'] for c in cases if c['kind']!='git'};probes=[]
 if 'java' in program_languages:probes.extend([('java',['java','--version']),('javac',['javac','--version'])])
 if 'cpp' in program_languages:probes.append(('cpp',['g++','--version']))
 if any(c['kind']=='git' for c in cases):probes.append(('git',['git','--version']))
 environment={'os':platform.platform(),'python':sys.version,'python_releaselevel':sys.version_info.releaselevel,'java_release':a.java_release}
 environment.update({key:run(cmd,ROOT) for key,cmd in probes})
 blocked_tools=[key for key,_ in probes if environment[key].get('returncode')!=0 or environment[key].get('error')]
 java_target=java_target_executed(environment,a.java_release) if 'java' in program_languages else False
 environment['targets']={'java':{'target':'Java25','target_executed':java_target and not blocked_tools,'scope':('target' if java_target else 'compatibility') if 'java' in program_languages else 'not_selected'},'cpp':{'target':'C++23','target_executed':'cpp' in program_languages and not blocked_tools,'scope':'C++23 mode' if 'cpp' in program_languages else 'not_selected'},'python':{'target':'Python3.15','target_executed':'python' in program_languages and sys.version_info[:2]==(3,15) and not blocked_tools,'scope':('target' if sys.version_info[:2]==(3,15) else 'compatibility') if 'python' in program_languages else 'not_selected'}}
 report={'chapter':14,'plan_sha256':sha(ROOT/'cases.json'),'script_sha256':sha(Path(__file__)),'started_utc':now(),'environment':environment,'records':[],'selected_languages':sorted(languages),'selected_case_ids':[c['id'] for c in cases],'status':'blocked' if blocked_tools else 'running','blocked_tools':blocked_tools,'summary':{'count':0,'matched':0}}
 out=Path(a.output) if a.output else ROOT/'output'/f"{a.language}_execution_{datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')}.json";out.parent.mkdir(parents=True,exist_ok=True)
 print('执行记录：'+str(out),flush=True)
 if blocked_tools:
  report['finished_utc']=now();out.write_text(json.dumps(report,ensure_ascii=False,indent=2))
  print('核查受阻，所需工具版本探测未成功：'+', '.join(blocked_tools),file=sys.stderr);return 2
 for c in cases:
  row={'id':c['id'],'expected':c['expected'],'started_utc':now()}
  try:
   with tempfile.TemporaryDirectory(prefix='chapter14_') as tmp:
    cwd,used,build,cmd=prepare(c,Path(tmp),a.java_release);row['source_sha256']=used
    if build:
     row['compile']=run(build,cwd)
     if c['expected']['type']=='compile_failure':row['matched']=matches(row['compile'],c['expected'])
     elif row['compile'].get('returncode')!=0:row['matched']=False;row['error']='Unexpected compilation failure; not treated as runtime evidence'
    if c['expected']['type']!='compile_failure' and ('compile' not in row or row['compile'].get('returncode')==0):
     row['run']=run(cmd,cwd);row['matched']=matches(row['run'],c['expected'])
     row['created_outputs_sha256']={str(f.relative_to(cwd)):sha(f) for f in cwd.rglob('*.tasks') if str(f.relative_to(cwd)) not in used.get('_staged_files',{})}
  except Exception as e:row['matched']=False;row['error']=repr(e)
  row['finished_utc']=now();report['records'].append(row);report['finished_utc']=now();report['summary']={'count':len(report['records']),'matched':sum(r['matched'] for r in report['records'])};out.write_text(json.dumps(report,ensure_ascii=False,indent=2));print(c['id'],row['matched'],flush=True)
 blocked=any(r.get(phase,{}).get('error') for r in report['records'] for phase in ['compile','run'])
 report['status']='blocked' if blocked else 'failed' if report['summary']['count']!=report['summary']['matched'] else 'completed'
 out.write_text(json.dumps(report,ensure_ascii=False,indent=2))
 if blocked:return 2
 return int(report['summary']['count']!=report['summary']['matched'])
if __name__=='__main__':sys.exit(main())
