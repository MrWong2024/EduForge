import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;

public class RestoreQueryChecks {
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args[0]);
        Files.createDirectories(root);
        String text = "TASKS-1\nTASK\tT-A\t条件练习\tCLOSED\n"
                + "SUBMIT\tS-1\t初稿\nSUBMIT\tS-2\t其他学生\nSUBMIT\tS-1\t修订稿\nEND\n";
        Path good = root.resolve("good.tasks");
        Files.writeString(good, text, StandardCharsets.UTF_8);
        LearningTask old = new LearningTask("OLD", "旧任务");
        SubmissionRecord oldRecord = new SubmissionRecord("OLD", "S-1", "旧提交");
        old.receive(oldRecord); old.close();
        TaskBoard board = new TaskBoard(); board.register(old);
        TaskSession session = new TaskSession(board);
        Path bad = root.resolve("bad.tasks");
        Files.writeString(bad, "TASKS-1\nTASK\tX\t标题\tOPEN\n", StandardCharsets.UTF_8);
        boolean failed = false;
        try { session.restore(bad); }
        catch (SnapshotFormatException e) { failed = true; }
        Checks.require(failed, "坏文件必须拒绝");
        Checks.require(session.getCurrent() == board, "坏文件保持原看板");
        Checks.require(old.findLatestByStudent("S-1") == oldRecord, "失败后仍可查询旧记录");
        session.restore(good);
        LearningTask loaded = session.getCurrent().find("T-A");
        SubmissionRecord found = loaded.findLatestByStudent("S-1");
        Checks.require(found == loaded.getHistory().get(2), "返回恢复后的第三条原记录");
        Checks.equalText("修订稿", found.getContent(), "顺序恢复后查询最近");
        Checks.require(!loaded.isOpen() && loaded.getHistory().size() == 3, "查询不动关闭状态和历史");
        Checks.require(old.findLatestByStudent("S-1") == oldRecord, "恢复成功不改旧对象");
        Path exported = root.resolve("new.tasks");
        SnapshotFile.saveNew(exported, session.getCurrent());
        Checks.equalText(text, Files.readString(exported, StandardCharsets.UTF_8), "新查询不增加存档字段");
        Checks.equalText(text, Files.readString(good, StandardCharsets.UTF_8), "未修改来源文件");
        System.out.println("恢复与新查询衔接检查通过");
    }
}
