import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** Expectations follow the TASKS-1 task page, not the serializer's output. */
public class SnapshotChecks {
    private static int assertions = 0;
    private static int scenarios = 0;
    private static void check(boolean condition, String label) {
        assertions++;
        if (!condition) throw new AssertionError(label);
    }
    private static final String GOOD = "TASKS-1\n"
            + "TASK\tT-A\t 条件练习 \tCLOSED\n"
            + "SUBMIT\tS-1\t初稿\n"
            + "SUBMIT\tS-1\t修订稿\n"
            + "SUBMIT\tS-1\t修订稿\n"
            + "TASK\tT-B\t循环练习\tOPEN\nEND\n";
    private static Path root;
    private static Path file(String name, String text) throws IOException {
        Path path = root.resolve(name);
        Files.writeString(path, text, StandardCharsets.UTF_8);
        return path;
    }
    private static TaskBoard original() {
        TaskBoard board = new TaskBoard();
        LearningTask old = new LearningTask("OLD", "原任务");
        old.receive(new SubmissionRecord("OLD", "S-0", "原有提交"));
        old.close();
        board.register(old);
        return board;
    }
    private static void preserved(TaskSession session, TaskBoard board,
                                  LearningTask task, SubmissionRecord record) {
        check(session.getCurrent() == board, "KEEP_BOARD");
        check(board.listTasks().size() == 1, "KEEP_SIZE");
        check(board.find("OLD") == task, "KEEP_TASK");
        check(!task.isOpen(), "KEEP_STATE");
        check(task.getTitle().equals("原任务"), "KEEP_TITLE");
        check(task.getHistory().size() == 1, "KEEP_HISTORY_SIZE");
        check(task.getHistory().get(0) == record, "KEEP_RECORD");
    }
    private static void reject(Path path, boolean format) throws Exception {
        scenarios++;
        TaskBoard board = original();
        LearningTask task = board.find("OLD");
        SubmissionRecord record = task.getHistory().get(0);
        TaskSession session = new TaskSession(board);
        boolean rejected = false;
        byte[] before = Files.exists(path) ? Files.readAllBytes(path) : null;
        try { session.restore(path); }
        catch (SnapshotFormatException e) {
            check(format, "EXPECTED_IO_NOT_FORMAT"); rejected = true;
        } catch (IOException e) {
            check(!format, "EXPECTED_FORMAT_NOT_IO"); rejected = true;
        }
        check(rejected, "REPORT_FAILURE");
        preserved(session, board, task, record);
        if (before != null) {
            check(java.util.Arrays.equals(before, Files.readAllBytes(path)), "KEEP_SOURCE_BYTES");
        } else check(!Files.exists(path), "NO_AUTO_CREATE_SOURCE");
    }
    private static void loaded(TaskBoard board) {
        check(board.listTasks().size() == 2, "TASK_COUNT");
        LearningTask a = board.find("T-A");
        LearningTask b = board.find("T-B");
        check(a != null && b != null, "BOTH_TASKS");
        check(board.listTasks().get(0) == a && board.listTasks().get(1) == b, "TASK_ORDER");
        check(a.getTitle().equals(" 条件练习 "), "RAW_TITLE");
        check(!a.isOpen() && b.isOpen(), "RESTORED_STATE");
        check(a.getHistory().size() == 3, "DUPLICATE_RECORDS");
        check(a.getHistory().get(0).getContent().equals("初稿"), "RECORD_ORDER");
        check(a.getHistory().get(1).getContent().equals("修订稿"), "RECORD_CONTENT");
        check(a.getHistory().get(2).getContent().equals("修订稿"), "REPEATED_CONTENT");
        for (SubmissionRecord r : a.getHistory()) {
            check(r.getTaskId().equals("T-A"), "RECORD_OWNER");
            check(r.getStudentId().equals("S-1"), "RECORD_STUDENT");
        }
        check(b.getHistory().isEmpty(), "EMPTY_HISTORY");
        check(!a.receive(new SubmissionRecord("T-A", "S-2", "后来")), "CLOSED_STILL_REJECTS");
        check(a.getHistory().size() == 3, "REFUSAL_NO_APPEND");
    }
    private static final class TrackingReader extends BufferedReader {
        boolean closed;
        int reads;
        final int failAt;
        final boolean failClose;
        TrackingReader(String input, int failAt, boolean failClose) {
            super(new StringReader(input));
            this.failAt = failAt; this.failClose = failClose;
        }
        @Override public String readLine() throws IOException {
            reads++;
            if (reads == failAt) throw new IOException("INJECTED_READ_FAILURE");
            return super.readLine();
        }
        @Override public void close() throws IOException {
            closed = true;
            super.close();
            if (failClose) throw new IOException("INJECTED_CLOSE_FAILURE");
        }
    }
    public static void main(String[] args) throws Exception {
        root = Path.of(args[0]); Files.createDirectories(root);
        scenarios++;
        Path good = file("good.tasks", GOOD);
        TaskBoard board = original(); LearningTask old = board.find("OLD");
        SubmissionRecord oldRecord = old.getHistory().get(0);
        TaskSession session = new TaskSession(board);
        session.restore(good);
        check(session.getCurrent() != board, "SWITCH_AFTER_SUCCESS");
        check(session.getCurrent().find("OLD") == null, "REPLACE_NOT_MERGE");
        loaded(session.getCurrent());
        check(board.find("OLD") == old && old.getHistory().get(0) == oldRecord, "OLD_REFERENCES_UNCHANGED");
        check(!old.isOpen(), "OLD_CLOSE_PRESERVED_ON_SUCCESS");
        check(Files.readString(good).equals(GOOD), "NO_INPUT_REWRITE");

        String[][] malformed = {
            {"empty", ""},
            {"version", "TASKS-2\nEND\n"},
            {"bom", "\uFEFFTASKS-1\nEND\n"},
            {"missing_end", "TASKS-1\nTASK\tX\t标题\tOPEN\n"},
            {"bad_state", "TASKS-1\nTASK\tX\t标题\tBROKEN\nEND\n"},
            {"late_bad_state", "TASKS-1\nTASK\tX\t标题\tOPEN\nSUBMIT\tA\t一\nTASK\tY\t另一项\tbad\nEND\n"},
            {"duplicate", "TASKS-1\nTASK\tX\t甲\tOPEN\nTASK\tX\t乙\tCLOSED\nEND\n"},
            {"orphan", "TASKS-1\nSUBMIT\tS\t内容\nEND\n"},
            {"empty_id", "TASKS-1\nTASK\t\t标题\tOPEN\nEND\n"},
            {"empty_title", "TASKS-1\nTASK\tX\t\tOPEN\nEND\n"},
            {"empty_content", "TASKS-1\nTASK\tX\t标题\tOPEN\nSUBMIT\tS\t\nEND\n"},
            {"empty_student", "TASKS-1\nTASK\tX\t标题\tOPEN\nSUBMIT\t\t内容\nEND\n"},
            {"extra_field", "TASKS-1\nTASK\tX\t标题\tOPEN\t多余\nEND\n"},
            {"blank_line", "TASKS-1\n\nEND\n"},
            {"after_end", "TASKS-1\nEND\nTASK\tX\t标题\tOPEN\n"},
            {"extra_blank", "TASKS-1\nEND\n\n"},
            {"unknown_tag", "TASKS-1\nOTHER\tX\nEND\n"}
        };
        for (String[] f : malformed) reject(file(f[0]+".tasks", f[1]), true);
        reject(root.resolve("absent.tasks"), false);
        Path invalid = root.resolve("bad_utf8.tasks");
        Files.write(invalid, new byte[]{(byte)0xFF,(byte)0xFE});
        reject(invalid, false);
        Path invalidLater = root.resolve("late_utf8.tasks");
        byte[] prefix = "TASKS-1\nTASK\tX\t有效\tOPEN\n".getBytes(StandardCharsets.UTF_8);
        byte[] bad = java.util.Arrays.copyOf(prefix,prefix.length+1); bad[prefix.length]=(byte)0xFF;
        Files.write(invalidLater,bad); reject(invalidLater,false);

        scenarios++;
        session.restore(file("valid_empty.tasks", "TASKS-1\nEND\n"));
        check(session.getCurrent().listTasks().isEmpty(), "VALID_EMPTY_REPLACES");
        scenarios++;
        loaded(SnapshotFile.load(file("crlf.tasks", GOOD.replace("\n","\r\n"))));
        scenarios++;
        loaded(SnapshotFile.load(file("no_final_newline.tasks", GOOD.substring(0,GOOD.length()-1))));
        scenarios++;
        TaskBoard exact = SnapshotFile.load(file("exact.tasks",
            "TASKS-1\nTASK\tA\t \tOPEN\nTASK\ta\t小写\tOPEN\nTASK\t A \t空格\tCLOSED\nEND\n"));
        check(exact.listTasks().size()==3, "EXACT_IDS");
        check(exact.find("A").getTitle().equals(" "), "SPACES_ARE_TEXT");

        scenarios++;
        TrackingReader normal = new TrackingReader(GOOD,-1,false);
        loaded(SnapshotFile.readAndClose(normal)); check(normal.closed,"CLOSE_SUCCESS");
        scenarios++;
        TrackingReader broken = new TrackingReader("TASKS-1\nBAD\n",-1,false);
        try { SnapshotFile.readAndClose(broken); throw new AssertionError("FORMAT_EXPECTED"); }
        catch (SnapshotFormatException e) { check(broken.closed,"CLOSE_AFTER_FORMAT"); }
        scenarios++;
        TrackingReader failRead = new TrackingReader(GOOD,4,false);
        try { SnapshotFile.readAndClose(failRead); throw new AssertionError("READ_EXPECTED"); }
        catch (IOException e) { check(e.getMessage().equals("INJECTED_READ_FAILURE"),"READ_KIND"); }
        check(failRead.reads==4 && failRead.closed,"CLOSE_AFTER_LATE_READ");
        scenarios++;
        TrackingReader failClose = new TrackingReader(GOOD,-1,true);
        boolean returned = false;
        try { SnapshotFile.readAndClose(failClose); returned=true; }
        catch (IOException e) { check(e.getMessage().equals("INJECTED_CLOSE_FAILURE"),"CLOSE_KIND"); }
        check(!returned && failClose.closed,"NO_SUCCESS_IF_CLOSE_FAILS");
        scenarios++;
        TrackingReader both = new TrackingReader("TASKS-1\nBAD\n",-1,true);
        try { SnapshotFile.readAndClose(both); throw new AssertionError("BOTH_EXPECTED"); }
        catch (SnapshotFormatException e) {
            check(both.closed,"BOTH_CLOSE_ATTEMPT");
            check(e.getSuppressed().length==1,"CLOSE_SUPPRESSED_NOT_LOST");
        }

        scenarios++;
        TaskBoard exportBoard = SnapshotFile.load(good);
        Path saved = root.resolve("saved.tasks"); SnapshotFile.saveNew(saved,exportBoard);
        check(Files.readString(saved,StandardCharsets.UTF_8).equals(GOOD),"EXPORT_EXPECTED_TEXT");
        check(!exportBoard.find("T-A").isOpen(),"EXPORT_KEEPS_STATE");
        check(exportBoard.find("T-A").getHistory().size()==3,"EXPORT_KEEPS_HISTORY");
        scenarios++;
        TaskBoard restored = SnapshotFile.load(saved); loaded(restored);
        check(restored.find("T-A")!=exportBoard.find("T-A"),"NEW_OBJECTS_ON_RESTORE");
        check(restored.find("T-A").getHistory().get(0)!=exportBoard.find("T-A").getHistory().get(0),"NEW_RECORD_OBJECTS");
        scenarios++;
        byte[] existing=Files.readAllBytes(saved); boolean existsRejected=false;
        try { SnapshotFile.saveNew(saved,new TaskBoard()); }
        catch (java.nio.file.FileAlreadyExistsException e) {existsRejected=true;}
        check(existsRejected,"NO_OVERWRITE");
        check(java.util.Arrays.equals(existing,Files.readAllBytes(saved)),"OLD_FILE_PRESERVED");
        scenarios++;
        TaskBoard unsupported = new TaskBoard(); unsupported.register(new LearningTask("X","两\n行"));
        Path unsupportedPath=root.resolve("unsupported.tasks"); boolean failed=false;
        try { SnapshotFile.saveNew(unsupportedPath,unsupported); }
        catch (SnapshotFormatException e) {failed=true;}
        check(failed && !Files.exists(unsupportedPath),"VALIDATE_BEFORE_CREATE");
        check(unsupported.find("X").getTitle().equals("两\n行"),"NO_TRIM_UNSUPPORTED");
        scenarios++;
        Path emptyOut=root.resolve("empty_export.tasks"); SnapshotFile.saveNew(emptyOut,new TaskBoard());
        check(Files.readString(emptyOut).equals("TASKS-1\nEND\n"),"EMPTY_EXPORT");
        System.out.println("SnapshotChecks: scenarios="+scenarios+", assertions="+assertions);
    }
}
