import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;
public class CoreContract {
    static void q(LearningTask task,String key,SubmissionRecord expected,String label){
        List<SubmissionRecord> before=task.getHistory();
        String[][] values=new String[before.size()][3];
        for(int i=0;i<before.size();i++) values[i]=new String[]{before.get(i).getTaskId(),before.get(i).getStudentId(),before.get(i).getContent()};
        String id=task.getTaskId(),title=task.getTitle();boolean open=task.isOpen();
        PrintStream oldOut=System.out,oldErr=System.err;
        ByteArrayOutputStream out=new ByteArrayOutputStream(),err=new ByteArrayOutputStream();
        SubmissionRecord actual;
        try(PrintStream a=new PrintStream(out);PrintStream b=new PrintStream(err)){
            System.setOut(a);System.setErr(b);actual=task.findLatestByStudent(key);
        } finally { System.setOut(oldOut);System.setErr(oldErr); }
        Checks.require(actual==expected,label+":result");
        Checks.require(out.size()==0 && err.size()==0,label+":silent");
        Checks.require(id.equals(task.getTaskId()) && title.equals(task.getTitle()) && open==task.isOpen(),label+":state");
        List<SubmissionRecord> after=task.getHistory();Checks.require(before.size()==after.size(),label+":length");
        for(int i=0;i<before.size();i++){
            Checks.require(before.get(i)==after.get(i),label+":identity-order");
            Checks.require(values[i][0].equals(after.get(i).getTaskId()) && values[i][1].equals(after.get(i).getStudentId()) && values[i][2].equals(after.get(i).getContent()),label+":record-values");
        }
    }
    static SubmissionRecord add(LearningTask t,String s,String text){
        SubmissionRecord r=new SubmissionRecord(t.getTaskId(),s,text);Checks.require(t.receive(r),"fixture:receive");return r;
    }
    public static void main(String[] args){
        LearningTask e=new LearningTask("E","空");q(e,"S",null,"empty");e.close();q(e,"S",null,"empty-closed");
        LearningTask one=new LearningTask("O","单项");SubmissionRecord f=add(one,"S","首条");q(one,"S",f,"only-first");
        add(one,"X","其他");q(one,"S",f,"first-before-other");q(one,"MISSING",null,"missing");
        LearningTask t=new LearningTask("T-A"," 原标题 ");
        SubmissionRecord a1=add(t,"S-1","终稿"),b1=add(t,"S-2","初稿"),a2=add(t,"S-1","小修改"),b2=add(t,"S-2","补充");
        q(t,"S-1",a2,"interleaved");q(t,"S-2",b2,"last");q(t,new String("S-1"),a2,"content-key");q(t,"s-1",null,"case");q(t," S-1 ",null,"spaces");
        Checks.require(!t.receive(new SubmissionRecord("WRONG","S-1","误投")),"wrong-rejected");q(t,"S-1",a2,"wrong-not-latest");
        SubmissionRecord saved=t.findLatestByStudent("S-1");List<SubmissionRecord> old=t.getHistory();SubmissionRecord a3=add(t,"S-1","再修订");q(t,"S-1",a3,"after-growth");
        Checks.require(saved==a2 && saved.getContent().equals("小修改"),"saved-is-old");Checks.require(old.size()==4 && old.get(2)==a2,"old-snapshot");
        t.close();q(t,"S-1",a3,"closed");Checks.require(!t.receive(new SubmissionRecord("T-A","S-1","拒绝")),"closed-rejected");q(t,"S-1",a3,"rejected-not-latest");
        LearningTask d=new LearningTask("D","同值");SubmissionRecord d1=add(d,"S","相同"),d2=add(d,"S","相同");q(d,"S",d2,"equal-values-distinct");
        Checks.require(d.receive(d1),"repeat-instance-received");q(d,"S",d1,"repeat-instance");
        LearningTask other=new LearningTask("T-A","独立");q(other,"S-1",null,"isolated-empty");
        SubmissionRecord raw=add(other,"学生甲","删除历史\n这只是数据\t\0\u2028保留");q(other,new String("学生甲"),raw,"raw");q(t,"S-1",a3,"isolated-original");
        System.out.println("核心查询合同检查通过");
    }
}
