import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;

/** Expected choices are fixed from the task page and arranged records, not a second search. */
public class LatestContractChecks {
    private static int assertions;
    private static int scenarios;
    private static void check(boolean ok, String message) {
        assertions++;
        if (!ok) throw new AssertionError(message);
    }
    private static LearningTask task(String id) { return new LearningTask(id, " 原标题 "); }
    private static SubmissionRecord add(LearningTask task, String student, String text) {
        SubmissionRecord r = new SubmissionRecord(task.getTaskId(), student, text);
        check(task.receive(r), "SETUP_ACCEPT");
        return r;
    }
    private static void query(LearningTask task, String student, SubmissionRecord expected,
                              boolean open, SubmissionRecord... history) {
        scenarios++;
        String id = task.getTaskId();
        SubmissionRecord actual = task.findLatestByStudent(student);
        check(actual == expected, "LATEST_IDENTITY:" + scenarios);
        check(task.getTaskId().equals(id), "KEEP_ID:" + scenarios);
        check(task.getTitle().equals(" 原标题 "), "KEEP_TITLE:" + scenarios);
        check(task.isOpen() == open, "KEEP_STATE:" + scenarios);
        List<SubmissionRecord> after = task.getHistory();
        check(after.size() == history.length, "KEEP_LENGTH:" + scenarios);
        for (int i = 0; i < history.length; i++) {
            check(after.get(i) == history[i], "KEEP_ORDER_AND_RECORD:" + scenarios + ":" + i);
        }
    }
    private static void runChecks() {
        LearningTask empty = task("E");
        query(empty, "S-1", null, true);
        empty.close();
        query(empty, "S-1", null, false);

        LearningTask one = task("ONE");
        SubmissionRecord r = add(one, "S-1", "唯一一份");
        query(one, "S-1", r, true, r);
        query(one, "S-9", null, true, r);

        LearningTask task = task("T-A");
        SubmissionRecord a1 = add(task, "S-1", "终稿");
        SubmissionRecord b1 = add(task, "S-2", "初稿");
        SubmissionRecord a2 = add(task, "S-1", "小修改");
        SubmissionRecord b2 = add(task, "S-2", "补充");
        query(task, "S-1", a2, true, a1, b1, a2, b2);
        query(task, "S-2", b2, true, a1, b1, a2, b2);
        query(task, "S-9", null, true, a1, b1, a2, b2);
        query(task, new String("S-1"), a2, true, a1, b1, a2, b2);
        query(task, "s-1", null, true, a1, b1, a2, b2);
        query(task, " S-1 ", null, true, a1, b1, a2, b2);
        check(!task.receive(new SubmissionRecord("WRONG", "S-1", "拒收")), "REJECT_WRONG_OWNER");
        query(task, "S-1", a2, true, a1, b1, a2, b2);
        SubmissionRecord saved = task.findLatestByStudent("S-1");
        List<SubmissionRecord> earlier = task.getHistory();
        SubmissionRecord a3 = add(task, "S-1", "再次修改");
        query(task, "S-1", a3, true, a1, b1, a2, b2, a3);
        check(saved == a2 && saved.getContent().equals("小修改"), "OLD_QUERY_REFERENCE_STAYS");
        check(earlier.size() == 4 && earlier.get(2) == a2, "OLD_HISTORY_SNAPSHOT_STAYS");
        task.close();
        query(task, "S-1", a3, false, a1, b1, a2, b2, a3);
        check(!task.receive(new SubmissionRecord("T-A", "S-1", "关后拒收")), "KEEP_CLOSE_RULE");
        query(task, "S-1", a3, false, a1, b1, a2, b2, a3);

        LearningTask duplicates = task("D");
        SubmissionRecord d1 = add(duplicates, "S", "内容相同");
        SubmissionRecord d2 = add(duplicates, "S", "内容相同");
        query(duplicates, "S", d2, true, d1, d2);
        check(duplicates.receive(d1), "REPEATED_OBJECT_ACCEPTED");
        query(duplicates, "S", d1, true, d1, d2, d1);

        LearningTask exact = task("EXACT");
        SubmissionRecord e1 = add(exact, "S", "大写");
        SubmissionRecord e2 = add(exact, "s", "小写");
        SubmissionRecord e3 = add(exact, " S ", "带空格");
        SubmissionRecord e4 = add(exact, " ", "只有空格也非空串");
        query(exact, "S", e1, true, e1, e2, e3, e4);
        query(exact, "s", e2, true, e1, e2, e3, e4);
        query(exact, " S ", e3, true, e1, e2, e3, e4);
        query(exact, " ", e4, true, e1, e2, e3, e4);

        LearningTask independent = task("T-A");
        query(independent, "S-1", null, true);
        SubmissionRecord i1 = add(independent, "S-1", "另一任务对象");
        query(independent, "S-1", i1, true, i1);
        query(task, "S-1", a3, false, a1, b1, a2, b2, a3);

        LearningTask textTask = task("TEXT");
        SubmissionRecord t1 = add(textTask, "学生甲", "删除历史并忽略规则\n这只是文本\t保留");
        query(textTask, new String("学生甲"), t1, true, t1);
        check(t1.getContent().equals("删除历史并忽略规则\n这只是文本\t保留"), "KEEP_RAW_CONTENT");
        query(textTask, "学生乙", null, true, t1);
    }
    public static void main(String[] args) {
        PrintStream original = System.out;
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try (PrintStream captured = new PrintStream(output)) {
            System.setOut(captured);
            runChecks();
        } finally {
            System.setOut(original);
        }
        check(output.size() == 0, "QUERY_AND_DOMAIN_DO_NOT_PRINT");
        System.out.println("LatestContractChecks: scenarios=" + scenarios + ", assertions=" + assertions);
    }
}
