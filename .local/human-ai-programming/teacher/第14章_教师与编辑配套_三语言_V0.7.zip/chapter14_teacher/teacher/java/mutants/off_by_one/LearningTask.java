import java.util.ArrayList;
import java.util.List;

/** Local, single-threaded teaching model; see the chapter contract. */
public final class LearningTask {
    private final String taskId;
    private final String title;
    private boolean open = true;
    private final ArrayList<SubmissionRecord> history = new ArrayList<>();

    public LearningTask(String taskId, String title) {
        this.taskId = taskId;
        this.title = title;
    }

    public String getTaskId() { return taskId; }
    public String getTitle() { return title; }
    public boolean isOpen() { return open; }
    public void close() { open = false; }

    public boolean receive(SubmissionRecord record) {
        if (!open || !taskId.equals(record.getTaskId())) {
            return false;
        }
        history.add(record);
        return true;
    }

    /** An unmodifiable snapshot, not a live view of the internal list. */
    public List<SubmissionRecord> getHistory() {
        return List.copyOf(history);
    }

    /** Latest accepted record for this student in this task; query only. */
    public SubmissionRecord findLatestByStudent(String studentId) {
        for (int i = history.size() - 1; i > 0; i = i - 1) {
            SubmissionRecord record = history.get(i);
            if (studentId.equals(record.getStudentId())) {
                return record;
            }
        }
        return null;
    }
}
