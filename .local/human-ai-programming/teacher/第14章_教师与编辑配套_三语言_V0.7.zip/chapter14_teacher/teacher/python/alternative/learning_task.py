from submission_record import SubmissionRecord


class LearningTask:
    def __init__(self, task_id: str, title: str):
        self._task_id = task_id
        self._title = title
        self._open = True
        self._history = []

    def get_task_id(self) -> str:
        return self._task_id

    def get_title(self) -> str:
        return self._title

    def is_open(self) -> bool:
        return self._open

    def close(self) -> None:
        self._open = False

    def receive(self, record: SubmissionRecord) -> bool:
        if not self._open or self._task_id != record.get_task_id():
            return False
        self._history.append(record)
        return True

    def get_history(self):
        return tuple(self._history)

    # 等价的正向扫描，只有匹配时才更新局部名字。
    def find_latest_by_student(self, student_id: str):
        latest = None
        for record in self._history:
            if record.get_student_id() == student_id:
                latest = record
        return latest
