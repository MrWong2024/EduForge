from pathlib import Path
from checks import require
from learning_task import LearningTask
from submission_record import SubmissionRecord
from task_board import TaskBoard
from task_session import TaskSession
from snapshot_file import save_new
from snapshot_format_error import SnapshotFormatError
text='TASKS-1\nTASK\tT-A\t条件练习\tCLOSED\nSUBMIT\tS-1\t初稿\nSUBMIT\tS-2\t其他\nSUBMIT\tS-1\t修订稿\nEND\n'
Path('good.tasks').write_text(text,encoding='utf-8')
Path('bad.tasks').write_text('TASKS-1\nTASK\tX\t标题\tOPEN\n',encoding='utf-8')
Path('empty.tasks').write_text('TASKS-1\nEND\n',encoding='utf-8')
b=TaskBoard();old=LearningTask('OLD','旧');r=SubmissionRecord('OLD','S-1','旧提交')
require(old.receive(r),'fixture-receive');old.close();require(b.register_task(old),'fixture-register')
s=TaskSession(b)
for name, kind in [('bad.tasks',SnapshotFormatError),('absent.tasks',OSError)]:
    failed=False
    try:s.restore(Path(name))
    except kind:failed=True
    require(failed,'expected-failure')
    require(s.get_current() is b and b.find('OLD') is old,'failure-old-identity')
    require(old.find_latest_by_student('S-1') is r and r.get_content()=='旧提交' and not old.is_open(),'failure-old-history')
s.restore(Path('good.tasks'));n=s.get_current();t=n.find('T-A')
require(n is not b and t is not old,'success-new')
require(t.find_latest_by_student('S-1') is t.get_history()[2],'loaded-latest-identity')
require(t.find_latest_by_student('S-1').get_content()=='修订稿','loaded-latest-value')
require(not t.is_open() and len(t.get_history())==3,'loaded-state')
require(not t.receive(SubmissionRecord('T-A','S-1','拒绝')),'keep-closed')
save_new(Path('export.tasks'),n)
require(Path('export.tasks').read_text(encoding='utf-8')==text,'unchanged-format')
require(Path('good.tasks').read_text(encoding='utf-8')==text,'source-unchanged')
s.restore(Path('empty.tasks'));require(s.get_current() is not n and s.get_current().list_tasks()==(),'empty-success-replaces')
require(old.find_latest_by_student('S-1') is r and n.find('T-A') is t,'old-aliases-stay')
print('恢复与新查询衔接检查通过')
