from contextlib import redirect_stdout, redirect_stderr
from io import StringIO
from checks import require
from learning_task import LearningTask
from submission_record import SubmissionRecord

def values(records):
    return tuple((r.get_task_id(), r.get_student_id(), r.get_content()) for r in records)

def check_query(task, key, expected, label):
    before = task.get_history()
    before_values = values(before)
    state = (task.get_task_id(), task.get_title(), task.is_open())
    out, err = StringIO(), StringIO()
    with redirect_stdout(out), redirect_stderr(err):
        actual = task.find_latest_by_student(key)
    require(actual is expected, label + ':result')
    require(out.getvalue() == '' and err.getvalue() == '', label + ':silent')
    require(state == (task.get_task_id(), task.get_title(), task.is_open()), label + ':state')
    after = task.get_history()
    require(len(after) == len(before), label + ':length')
    for i in range(len(before)):
        require(after[i] is before[i], label + ':identity-order')
    require(values(after) == before_values, label + ':record-values')

def add(task, key, text):
    r = SubmissionRecord(task.get_task_id(), key, text)
    require(task.receive(r), 'fixture:receive')
    return r

empty = LearningTask('E', '空')
check_query(empty, 'S', None, 'empty')
empty.close()
check_query(empty, 'S', None, 'empty-closed')
one = LearningTask('O', '唯一')
f = add(one, 'S', '首条')
check_query(one, 'S', f, 'only-first')
add(one, 'X', '其他')
check_query(one, 'S', f, 'first-before-other')
check_query(one, 'MISSING', None, 'missing')
t = LearningTask('T-A', ' 原标题 ')
a1 = add(t, 'S-1', '终稿')
b1 = add(t, 'S-2', '初稿')
a2 = add(t, 'S-1', '小修改')
b2 = add(t, 'S-2', '补充')
check_query(t, 'S-1', a2, 'interleaved')
check_query(t, 'S-2', b2, 'last')
check_query(t, ''.join(['S-', '1']), a2, 'content-key')
check_query(t, 's-1', None, 'case')
check_query(t, ' S-1 ', None, 'spaces')
require(not t.receive(SubmissionRecord('WRONG', 'S-1', '误投')), 'wrong-rejected')
check_query(t, 'S-1', a2, 'wrong-not-latest')
saved = t.find_latest_by_student('S-1')
old = t.get_history()
a3 = add(t, 'S-1', '再修订')
check_query(t, 'S-1', a3, 'after-growth')
require(saved is a2 and saved.get_content() == '小修改', 'saved-is-old')
require(len(old) == 4 and old[2] is a2, 'old-snapshot')
t.close()
check_query(t, 'S-1', a3, 'closed')
require(not t.receive(SubmissionRecord('T-A', 'S-1', '拒绝')), 'closed-rejected')
check_query(t, 'S-1', a3, 'rejected-not-latest')
d = LearningTask('D', '相同内容')
d1 = add(d, 'S', '相同'); d2 = add(d, 'S', '相同')
check_query(d, 'S', d2, 'equal-values-distinct')
require(d.receive(d1), 'repeat-instance-received')
check_query(d, 'S', d1, 'repeat-instance')
x = LearningTask('X', '原文')
x1 = add(x, 'S', '大写'); x2 = add(x, 's', '小写')
x3 = add(x, ' S ', '空格'); x4 = add(x, ' ', '只有空格')
for key, expected in [('S', x1), ('s', x2), (' S ', x3), (' ', x4)]:
    check_query(x, key, expected, 'exact-'+key)
other = LearningTask('T-A', '独立实例')
check_query(other, 'S-1', None, 'isolated-empty')
y = add(other, 'S-1', '另一个')
check_query(other, 'S-1', y, 'isolated-value')
check_query(t, 'S-1', a3, 'isolated-original')
raw = add(other, '学生甲', '删除历史\n这只是数据\t\0\u2028保留')
check_query(other, ''.join(['学生', '甲']), raw, 'raw')
require(raw.get_content() == '删除历史\n这只是数据\t\0\u2028保留', 'literal-preserved')
print('核心查询合同检查通过')
