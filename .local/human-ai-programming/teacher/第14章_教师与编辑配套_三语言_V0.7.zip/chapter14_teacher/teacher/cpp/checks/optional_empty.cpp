#include <iostream>
#include <optional>
#include "checks.hpp"
#include "learning_task.hpp"
int main(){const LearningTask task("E","空");auto r=task.findLatestByStudent("S");
Checks::require(!r.has_value(),"absent");bool failed=false;
try{(void)r.value();}catch(const std::bad_optional_access&){failed=true;}
Checks::require(failed,"value-without-result-throws");std::cout<<"空可选值边界检查通过\n";}
