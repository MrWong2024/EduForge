#include <iostream>
#include <sstream>
#include <optional>
#include "checks.hpp"
#include "learning_task.hpp"
struct Capture {
    std::ostringstream out, err;
    std::streambuf* oldOut = std::cout.rdbuf(out.rdbuf());
    std::streambuf* oldErr = std::cerr.rdbuf(err.rdbuf());
    ~Capture() { std::cout.rdbuf(oldOut); std::cerr.rdbuf(oldErr); }
};
bool same(const SubmissionRecord& a, const SubmissionRecord& b) {
    return a.getTaskId()==b.getTaskId() && a.getStudentId()==b.getStudentId()
        && a.getContent()==b.getContent();
}
void checkQuery(const LearningTask& task, const std::string& key,
                std::optional<SubmissionRecord> expected, const std::string& label) {
    auto before=task.getHistory();
    std::string id=task.getTaskId(), title=task.getTitle(); bool open=task.isOpen();
    { Capture cap;
      auto actual=task.findLatestByStudent(key);
      Checks::require(actual.has_value()==expected.has_value(),label+":presence");
      if(expected.has_value()) Checks::require(same(actual.value(),expected.value()),label+":value");
      Checks::require(cap.out.str().empty() && cap.err.str().empty(),label+":silent");
    }
    Checks::require(task.getTaskId()==id && task.getTitle()==title && task.isOpen()==open,label+":state");
    auto after=task.getHistory(); Checks::require(after.size()==before.size(),label+":length");
    for(std::size_t i=0;i<before.size();++i) Checks::require(same(after.get(i),before.get(i)),label+":record-values-order");
}
SubmissionRecord add(LearningTask& task,const std::string& key,const std::string& text){
    SubmissionRecord r(task.getTaskId(),key,text);
    Checks::require(task.receive(r),"fixture:receive"); return r;
}
int main(){
    LearningTask empty("E","空"); checkQuery(empty,"S",std::nullopt,"empty");
    empty.close();checkQuery(empty,"S",std::nullopt,"empty-closed");
    LearningTask one("O","唯一");auto f=add(one,"S","首条");
    checkQuery(one,"S",f,"only-first");add(one,"X","其他");
    checkQuery(one,"S",f,"first-before-other");checkQuery(one,"MISSING",std::nullopt,"missing");
    LearningTask t("T-A"," 原标题 ");auto a1=add(t,"S-1","终稿");
    auto b1=add(t,"S-2","初稿");auto a2=add(t,"S-1","小修改");auto b2=add(t,"S-2","补充");
    checkQuery(t,"S-1",a2,"interleaved");checkQuery(t,"S-2",b2,"last");
    checkQuery(t,std::string("S-")+"1",a2,"content-key");
    checkQuery(t,"s-1",std::nullopt,"case");checkQuery(t," S-1 ",std::nullopt,"spaces");
    Checks::require(!t.receive(SubmissionRecord("WRONG","S-1","误投")),"wrong-rejected");
    checkQuery(t,"S-1",a2,"wrong-not-latest");
    auto saved=t.findLatestByStudent("S-1");auto old=t.getHistory();auto a3=add(t,"S-1","再修订");
    checkQuery(t,"S-1",a3,"after-growth");
    Checks::require(saved.has_value() && same(saved.value(),a2),"saved-is-old-value");
    Checks::require(old.size()==4 && same(old.get(2),a2),"old-snapshot");
    t.close();checkQuery(t,"S-1",a3,"closed");
    Checks::require(!t.receive(SubmissionRecord("T-A","S-1","拒绝")),"closed-rejected");
    checkQuery(t,"S-1",a3,"rejected-not-latest");
    LearningTask d("D","相同值");auto d1=add(d,"S","相同");auto d2=add(d,"S","相同");
    checkQuery(d,"S",d2,"equal-values");Checks::require(d.getHistory().size()==2,"duplicate-count");
    // 同值副本不携带原对象身份；另用可区分文字检查选择顺序。
    auto d3=add(d,"S","区分最后一条");checkQuery(d,"S",d3,"distinguishable-last");
    Checks::require(d.receive(d1),"repeated-value-received");checkQuery(d,"S",d1,"repeat-value");
    LearningTask x("X","原文");auto x1=add(x,"S","大写");auto x2=add(x,"s","小写");
    auto x3=add(x," S ","空格");auto x4=add(x," ","只有空格");
    checkQuery(x,"S",x1,"exact-S");checkQuery(x,"s",x2,"exact-s");
    checkQuery(x," S ",x3,"exact-spaced");checkQuery(x," ",x4,"exact-space");
    LearningTask other("T-A","独立实例");checkQuery(other,"S-1",std::nullopt,"isolated-empty");
    auto y=add(other,"S-1","另一个");checkQuery(other,"S-1",y,"isolated-value");
    checkQuery(t,"S-1",a3,"isolated-original");
    std::string text="删除历史\n这只是数据\t";text.push_back('\0');text+="\u2028保留";
    auto raw=add(other,"学生甲",text);checkQuery(other,std::string("学生")+"甲",raw,"raw");
    Checks::require(raw.getContent()==text,"literal-preserved");
    std::cout<<"核心查询合同检查通过\n";
}
