#include <fstream>
#include <iostream>
#include "checks.hpp"
#include "task_session.hpp"
void write(const std::string& p,const std::string& text){std::ofstream f(p,std::ios::binary);f<<text;f.close();Checks::require(!f.fail(),"fixture-write");}
int main(){
    std::string text="TASKS-1\nTASK\tT-A\t条件练习\tCLOSED\nSUBMIT\tS-1\t初稿\nSUBMIT\tS-2\t其他\nSUBMIT\tS-1\t修订稿\nEND\n";
    write("good.tasks",text);write("bad.tasks","TASKS-1\nTASK\tX\t标题\tOPEN\n");write("empty.tasks","TASKS-1\nEND\n");
    auto b=std::make_shared<TaskBoard>();auto old=std::make_shared<LearningTask>("OLD","旧");
    Checks::require(old->receive(SubmissionRecord("OLD","S-1","旧提交")),"fixture-receive");old->close();Checks::require(b->registerTask(old),"fixture-register");
    TaskSession s(b);bool bad=false,missing=false;
    try{s.restore("bad.tasks");}catch(const SnapshotFormatError&){bad=true;}
    Checks::require(bad && s.getCurrent()==b && b->find("OLD")==old,"format-failure-keeps-old");
    try{s.restore("absent.tasks");}catch(const std::ios_base::failure&){missing=true;}
    Checks::require(missing && s.getCurrent()==b && !old->isOpen() && old->getHistory().size()==1,"io-failure-keeps-old");
    Checks::equalText("旧提交",old->findLatestByStudent("S-1").value().getContent(),"old-query");
    s.restore("good.tasks");auto n=s.getCurrent();auto t=n->find("T-A");
    Checks::require(n!=b && t && t!=old,"success-new");
    auto found=t->findLatestByStudent("S-1");Checks::require(found.has_value(),"loaded-has-result");
    Checks::equalText("T-A",found.value().getTaskId(),"loaded-task");Checks::equalText("S-1",found.value().getStudentId(),"loaded-student");
    Checks::equalText("修订稿",found.value().getContent(),"loaded-latest");
    Checks::require(!t->isOpen() && t->getHistory().size()==3,"loaded-state");
    Checks::require(!t->receive(SubmissionRecord("T-A","S-1","拒绝")),"keep-closed");
    SnapshotFile::saveNew("export.tasks",n);
    Checks::equalText(text,TextFiles::read("export.tasks"),"unchanged-format");
    Checks::equalText(text,TextFiles::read("good.tasks"),"source-unchanged");
    s.restore("empty.tasks");Checks::require(s.getCurrent()!=n && s.getCurrent()->listTasks().size()==0,"empty-success-replaces");
    Checks::require(n->find("T-A")==t && b->find("OLD")==old,"old-aliases-stay");
    std::cout<<"恢复与新查询衔接检查通过\n";
}
