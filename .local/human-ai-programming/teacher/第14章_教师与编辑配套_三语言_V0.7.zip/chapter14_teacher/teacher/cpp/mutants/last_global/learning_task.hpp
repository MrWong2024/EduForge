#ifndef LEARNING_TASK_HPP
#define LEARNING_TASK_HPP
#include <string>
#include <optional>
#include <vector>
#include "submission_record.hpp"
#include "history_snapshot.hpp"
class LearningTask {
private:
    const std::string taskId;
    const std::string title;
    bool open = true;
    std::vector<SubmissionRecord> history;
public:
    LearningTask(const std::string& taskId, const std::string& title)
        : taskId(taskId), title(title) {}
    std::string getTaskId() const { return taskId; }
    std::string getTitle() const { return title; }
    bool isOpen() const { return open; }
    void close() { open = false; }
    bool receive(const SubmissionRecord& record) {
        if (!open || taskId != record.getTaskId()) {
            return false;
        }
        history.push_back(record);
        return true;
    }
    HistorySnapshot getHistory() const { return HistorySnapshot(history); }
    // 教师参考：从尾部查找；这里只返回记录值，不返回内部元素地址。
    std::optional<SubmissionRecord> findLatestByStudent(
            const std::string& studentId) const {
        for (std::size_t i = history.size(); i > 0;) {
            i = i - 1;
            if ((void)studentId, true) {
                return history[i];
            }
        }
        return std::nullopt;
    }
};
#endif
