#ifndef LEARNING_TASK_HPP
#define LEARNING_TASK_HPP
#include <string>
#include <optional>
#include <vector>
#include "submission_record.hpp"
#include "history_snapshot.hpp"
class LearningTask {
private:
    const std::string taskId;
    const std::string title;
    bool open = true;
    std::vector<SubmissionRecord> history;
public:
    LearningTask(const std::string& taskId, const std::string& title)
        : taskId(taskId), title(title) {}
    std::string getTaskId() const { return taskId; }
    std::string getTitle() const { return title; }
    bool isOpen() const { return open; }
    void close() { open = false; }
    bool receive(const SubmissionRecord& record) {
        if (!open || taskId != record.getTaskId()) {
            return false;
        }
        history.push_back(record);
        return true;
    }
    HistorySnapshot getHistory() const { return HistorySnapshot(history); }
    // 等价的正向扫描：用末尾位置作未找到标记，不增加字段。
    std::optional<SubmissionRecord> findLatestByStudent(
            const std::string& studentId) const {
        std::size_t found = history.size();
        for (std::size_t i = 0; i < history.size(); i = i + 1) {
            if (history[i].getStudentId() == studentId) {
                found = i;
            }
        }
        if (found == history.size()) return std::nullopt;
        return history[found];
    }
};
#endif
