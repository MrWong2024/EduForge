"""Reassemble the recovered chapter14 editorial source; requires python-docx.
Layout files contain styles/layout, not an alternative copy of the body prose.
Shared text/table nodes are maintained once in chapter.json. Language sequences
point to them; executable snippets read the actual source file line range.
"""
from pathlib import Path
import argparse,datetime,json,textwrap
from docx import Document
from docx.text.paragraph import Paragraph
from docx.table import Table
from docx.oxml.ns import qn
ROOT=Path(__file__).resolve().parent
def text(node):
 if 'source' not in node:return node['text']
 r=node['source'];s='\n'.join((ROOT/r['path']).read_text().splitlines()[r['start']-1:r['start']-1+r['count']]);return textwrap.dedent(s)if r.get('dedent')else s

def setpara(p,s):
 if not p.runs:p.add_run()
 p.runs[0].text=s
 for r in p.runs[1:]:r.text=''
def main():
 p=argparse.ArgumentParser();p.add_argument('--language',choices=['all','java','cpp','python'],default='all');p.add_argument('--output-dir',default='assembled');a=p.parse_args()
 ch=json.loads((ROOT/'chapter.json').read_text());out=Path(a.output_dir);out.mkdir(parents=True,exist_ok=True)
 for lang in ch['sequences']if a.language=='all'else[a.language]:
  d=Document(ROOT/ch['layout'][lang]);nodes=iter(ch['sequences'][lang])
  for el in d.element.body:
   if el.tag==qn('w:p'):setpara(Paragraph(el,d),text(ch['nodes'][next(nodes)]))
   elif el.tag==qn('w:tbl'):
    node=ch['nodes'][next(nodes)];table=Table(el,d)
    for row,contents in zip(table.rows,node['rows']):
     for cell,s in zip(row.cells,contents):
      setpara(cell.paragraphs[0],s)
      for p in cell.paragraphs[1:]:setpara(p,'')
  label={'java':'Java','cpp':'C++','python':'Python'}[lang]
  d.core_properties.modified=datetime.datetime.now(datetime.timezone.utc)
  version=ch['versions'].get('text_by_language',{}).get(lang,ch['versions']['text'])
  d.core_properties.version=version.removeprefix('V')
  d.save(out/f"第14章_{ch['title']}_{label}_{version}.docx")
  for rel,s in ch['student_text'][lang].items():
   f=ROOT/'student'/lang/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
if __name__=='__main__':main()
