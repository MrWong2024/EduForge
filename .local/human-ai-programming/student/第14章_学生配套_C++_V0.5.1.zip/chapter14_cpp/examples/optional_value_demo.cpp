#include <iostream>
#include <optional>
#include "submission_record.hpp"
int main() {
    std::optional<SubmissionRecord> found = SubmissionRecord("T-A", "S-1", "初稿");
    std::optional<SubmissionRecord> missing = std::nullopt;
    std::cout << std::boolalpha << found.has_value() << "\n";
    if (found.has_value()) std::cout << found.value().getContent() << "\n";
    std::cout << missing.has_value() << "\n";
}
