#include <cstddef>
#include <iostream>
#include <vector>
int main() {
    std::vector<int> minutes = {15, 40, 30, 55, 20};
    for (std::size_t i = minutes.size(); i > 0;) {
        i = i - 1;
        std::cout << i << ":" << minutes[i] << "\n";
    }
}
