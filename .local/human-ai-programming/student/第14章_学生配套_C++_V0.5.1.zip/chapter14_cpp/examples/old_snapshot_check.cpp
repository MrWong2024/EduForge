#include <iostream>
#include "checks.hpp"
#include "learning_task.hpp"

int main() {
    LearningTask task("T-A", "条件练习");
    Checks::require(task.receive(SubmissionRecord("T-A", "S-1", "初稿")), "接收初稿");
    HistorySnapshot earlier = task.getHistory();
    Checks::require(task.receive(SubmissionRecord("T-A", "S-1", "修订稿")), "接收修订稿");
    Checks::require(earlier.size() == 1, "旧名单仍只有一条");
    Checks::equalText("初稿", earlier.get(0).getContent(), "旧名单保留初稿值");
    Checks::require(task.getHistory().size() == 2, "当前历史有两条");
    Checks::equalText("修订稿", task.getHistory().get(1).getContent(), "修订稿在末尾");
    std::cout << "旧快照检查通过\n";
}
