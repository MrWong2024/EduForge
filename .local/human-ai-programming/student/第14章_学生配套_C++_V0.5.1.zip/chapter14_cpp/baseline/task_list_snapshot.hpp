#ifndef TASK_LIST_SNAPSHOT_HPP
#define TASK_LIST_SNAPSHOT_HPP
#include <cstddef>
#include <vector>
#include "task_handle.hpp"
// 已提供的名单工具：固定名单，仍访问原来的任务。
class TaskListSnapshot {
private:
    const std::vector<TaskHandle> items;
public:
    explicit TaskListSnapshot(const std::vector<TaskHandle>& source)
        : items(source) {}
    std::size_t size() const { return items.size(); }
    // index必须小于size()。返回的是句柄副本，不是任务副本。
    TaskHandle get(std::size_t index) const { return items.at(index); }
};
#endif
