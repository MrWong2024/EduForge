#ifndef SUBMISSION_RECORD_HPP
#define SUBMISSION_RECORD_HPP
#include <string>
class SubmissionRecord {
private:
    const std::string taskId;
    const std::string studentId;
    const std::string content;
public:
    SubmissionRecord(const std::string& taskId,
                     const std::string& studentId,
                     const std::string& content)
        : taskId(taskId), studentId(studentId), content(content) {}
    std::string getTaskId() const { return taskId; }
    std::string getStudentId() const { return studentId; }
    std::string getContent() const { return content; }
};
#endif
