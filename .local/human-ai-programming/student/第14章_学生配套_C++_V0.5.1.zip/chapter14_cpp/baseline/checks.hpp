#ifndef CH12_CHECKS_HPP
#define CH12_CHECKS_HPP
#include <stdexcept>
#include <string>
namespace Checks {
inline void require(bool condition, const std::string& message) {
    if (!condition) {
        throw std::runtime_error(message);
    }
}
inline void equalText(const std::string& expected, const std::string& actual,
                      const std::string& message) {
    require(expected == actual, message
            + "；预期=[" + expected + "]；实际=[" + actual + "]");
}
}
#endif
