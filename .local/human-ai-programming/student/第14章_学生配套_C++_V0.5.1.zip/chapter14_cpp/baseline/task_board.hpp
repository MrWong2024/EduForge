#ifndef CH13_TASK_BOARD_HPP
#define CH13_TASK_BOARD_HPP
#include <unordered_map>
#include <vector>
#include "task_list_snapshot.hpp"
class TaskBoard {
    std::unordered_map<std::string, TaskHandle> byId;
    std::vector<std::string> order;
public:
    bool registerTask(TaskHandle task) {
        std::string id = task->getTaskId();
        if (byId.find(id) != byId.end()) return false;
        byId.emplace(id, task);
        order.push_back(id);
        return true;
    }
    TaskHandle find(const std::string& id) const {
        auto it = byId.find(id);
        if (it == byId.end()) return nullptr;
        return it->second;
    }
    TaskListSnapshot listTasks() const {
        std::vector<TaskHandle> result;
        for (const std::string& id : order) result.push_back(byId.at(id));
        return TaskListSnapshot(result);
    }
};
#endif
