#ifndef HISTORY_SNAPSHOT_HPP
#define HISTORY_SNAPSHOT_HPP
#include <cstddef>
#include <vector>
#include "submission_record.hpp"
// 本章提供的只读快照工具；不是标准库类型。
class HistorySnapshot {
private:
    const std::vector<SubmissionRecord> items;
public:
    explicit HistorySnapshot(const std::vector<SubmissionRecord>& source)
        : items(source) {}
    std::size_t size() const { return items.size(); }
    // 调用者保证index < size()；按值交回，不暴露内部元素引用。
    SubmissionRecord get(std::size_t index) const { return items[index]; }
};
#endif
