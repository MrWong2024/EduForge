#ifndef TASK_HANDLE_HPP
#define TASK_HANDLE_HPP
#include <memory>
#include "learning_task.hpp"
// 简写的是一个标准库类型，不是新业务角色。
using TaskHandle = std::shared_ptr<LearningTask>;
#endif
