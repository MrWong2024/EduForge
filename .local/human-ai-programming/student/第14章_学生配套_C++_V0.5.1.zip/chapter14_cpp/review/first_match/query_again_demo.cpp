#include <iostream>
#include "checks.hpp"
#include "learning_task.hpp"

int main() {
    LearningTask task("T-A", "条件练习");
    Checks::require(task.receive(SubmissionRecord("T-A", "S-1", "初稿")), "接收初稿");
    auto saved = task.findLatestByStudent("S-1");
    Checks::require(saved.has_value(), "先前应找到初稿");
    Checks::require(task.receive(SubmissionRecord("T-A", "S-1", "修订稿")), "接收修订稿");
    auto now = task.findLatestByStudent("S-1");
    Checks::require(now.has_value(), "现在应有结果");
    std::cout << saved.value().getContent() << "\n";
    std::cout << now.value().getContent() << "\n";
    std::cout << task.getHistory().size() << "\n";
}
