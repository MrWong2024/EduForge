#include <iostream>
#include "checks.hpp"
#include "task_board.hpp"
int main() {
    TaskHandle task = std::make_shared<LearningTask>("T-A", "条件练习");
    TaskHandle other = std::make_shared<LearningTask>("T-B", "循环练习");
    SubmissionRecord first("T-A", "S-1", "初稿");
    Checks::require(task->isOpen(), "新任务应开放");
    Checks::require(task->receive(first), "第一次应接收");
    HistorySnapshot earlier = task->getHistory();
    Checks::require(task->receive(first), "再次接收相同记录值也应追加");
    Checks::require(earlier.size() == 1, "旧快照不随追加改变");
    Checks::require(task->getHistory().size() == 2, "两次接收保留两条");
    Checks::equalText("初稿", task->getHistory().get(0).getContent(), "首条值保留");
    Checks::equalText("初稿", task->getHistory().get(1).getContent(), "第二条值保留");
    Checks::require(!other->receive(first), "归属错误应拒绝");
    Checks::require(other->getHistory().size() == 0, "拒绝后仍无历史");
    task->close();
    task->close();
    Checks::require(!task->isOpen(), "重复关闭不重开");
    Checks::require(other->isOpen(), "另一任务仍开放");
    Checks::require(!task->receive(first), "关闭后不接收");
    Checks::require(task->getHistory().size() == 2, "关闭拒绝不删历史");
    TaskBoard board;
    Checks::require(board.registerTask(task), "第一次登记成功");
    Checks::require(!board.registerTask(
        std::make_shared<LearningTask>("T-A", "替换")), "重复编号拒绝");
    Checks::require(board.find("T-A") == task, "仍是原任务");
    Checks::require(board.find("missing") == nullptr, "缺失不创建对象");
    std::cout << "原有行为检查通过\n";
}
