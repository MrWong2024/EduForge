#include <iostream>
#include "checks.hpp"
#include "learning_task.hpp"

void sameRecord(const SubmissionRecord& expected, const SubmissionRecord& actual,
                const std::string& message) {
    Checks::require(expected.getTaskId() == actual.getTaskId()
        && expected.getStudentId() == actual.getStudentId()
        && expected.getContent() == actual.getContent(), message);
}
void latestIs(const LearningTask& task, const std::string& student,
              const SubmissionRecord& expected, const std::string& message) {
    auto actual = task.findLatestByStudent(student);
    Checks::require(actual.has_value(), message + "：应有结果");
    sameRecord(expected, actual.value(), message);
}
int main() {
    LearningTask empty("E", "空历史");
    Checks::require(!empty.findLatestByStudent("S-1").has_value(), "空历史没有匹配项");
    LearningTask task("T-A", "条件练习");
    SubmissionRecord a1("T-A", "S-1", "初稿");
    SubmissionRecord b1("T-A", "S-2", "初稿");
    SubmissionRecord a2("T-A", "S-1", "修订稿");
    SubmissionRecord b2("T-A", "S-2", "补充");
    Checks::require(task.receive(a1), "接收a1");
    Checks::require(task.receive(b1), "接收b1");
    Checks::require(task.receive(a2), "接收a2");
    Checks::require(task.receive(b2), "接收b2");

    HistorySnapshot before = task.getHistory();
    latestIs(task, "S-1", a2, "S-1最近应为a2的值");
    latestIs(task, "S-2", b2, "S-2最近应为b2的值");
    Checks::require(!task.findLatestByStudent("S-9").has_value(), "不存在的学生无结果");
    latestIs(task, std::string("S-") + "1", a2, "比较完整文字");
    Checks::require(!task.findLatestByStudent("s-1").has_value(), "不忽略大小写");
    Checks::require(!task.findLatestByStudent(" S-1 ").has_value(), "不自动去空格");
    HistorySnapshot after = task.getHistory();
    Checks::require(after.size() == before.size(), "查询不改变历史条数");
    for (std::size_t i = 0; i < before.size(); i = i + 1) {
        sameRecord(before.get(i), after.get(i), "记录值与次序保持");
    }
    Checks::require(task.isOpen(), "查询不关闭任务");
    Checks::equalText("T-A", task.getTaskId(), "保留编号");
    Checks::equalText("条件练习", task.getTitle(), "保留标题");
    SubmissionRecord rejected("T-B", "S-1", "不能算最近");
    Checks::require(!task.receive(rejected), "错误归属被拒绝");
    latestIs(task, "S-1", a2, "拒收不参与查询");
    task.close();
    latestIs(task, "S-1", a2, "关闭后仍能查询");
    Checks::require(!task.receive(
        SubmissionRecord("T-A", "S-1", "关闭后尝试")), "不放宽关闭规则");
    latestIs(task, "S-1", a2, "失败尝试不变成最新");
    Checks::require(!task.isOpen(), "查询不重新开放任务");
    Checks::require(task.getHistory().size() == 4, "旧历史仍为四条");
    std::cout << "新查询检查通过\n";
}
