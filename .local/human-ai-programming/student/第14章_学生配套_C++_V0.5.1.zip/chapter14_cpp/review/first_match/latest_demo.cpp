#include <iostream>
#include "checks.hpp"
#include "learning_task.hpp"
int main() {
    LearningTask task("T-A", "条件练习");
    SubmissionRecord a1("T-A", "S-1", "初稿");
    SubmissionRecord b1("T-A", "S-2", "初稿");
    SubmissionRecord a2("T-A", "S-1", "修订稿");
    SubmissionRecord b2("T-A", "S-2", "补充");
    Checks::require(task.receive(a1), "接收a1");
    Checks::require(task.receive(b1), "接收b1");
    Checks::require(task.receive(a2), "接收a2");
    Checks::require(task.receive(b2), "接收b2");

    std::optional<SubmissionRecord> found = task.findLatestByStudent("S-1");
    Checks::require(found.has_value(), "S-1应有结果");
    std::cout << std::boolalpha;
    std::cout << found.value().getContent() << "\n";
    std::cout << (found.value().getTaskId() == a2.getTaskId()
        && found.value().getStudentId() == a2.getStudentId()
        && found.value().getContent() == a2.getContent()) << "\n";
    std::cout << task.getHistory().size() << "\n";
    std::cout << !task.findLatestByStudent("S-9").has_value() << "\n";
}
