# AI任务委托卡

这是第14章本语言任务卡的文字版。把附件和运行条件换成你实际使用的内容，不把待执行计划写成结果。

## 目标

为LearningTask增加findLatestByStudent(const std::string& studentId) const，返回std::optional<SubmissionRecord>。只查当前任务的已接收历史，选择指定学生最后被接收的记录，按值返回其完整内容；空历史或无匹配返回std::nullopt。

## 已知代码

随附表14-3列出的work文件。studentId为非空std::string，按完整文字精确比较，不去空格、不忽略大小写。记录值仍按次序保存；不处理身份认证或查询权限。

## 不能改变

关闭任务仍可查询。查询不打印，不改变编号、标题、开放状态、历史数量、次序或任何记录值。已有方法保持原行为，重复提交继续逐条保留。

## 修改范围

只在work/learning_task.hpp增加此方法、必要短说明及#include <optional>；不增加字段、第三方依赖或文件格式改动。补检查另建work/latest_extra_checks.cpp，不改写已有检查和预期。

## 怎样算完成

给出思路及实际差异，运行普通／缺失／重复／关闭／历史保持检查与旧检查，说明实际命令和结果。未执行项单独说明；计划或代码不是执行证据。
