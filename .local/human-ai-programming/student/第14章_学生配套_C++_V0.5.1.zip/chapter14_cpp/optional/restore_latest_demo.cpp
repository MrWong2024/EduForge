#include <iostream>
#include "checks.hpp"
#include "snapshot_file.hpp"
int main() {
    auto board = SnapshotFile::load("optional/samples/good.tasks");
    TaskHandle task = board->find("T-A");
    Checks::require(task != nullptr, "应恢复T-A");
    auto found = task->findLatestByStudent("S-1");
    Checks::require(found.has_value(), "恢复后应有结果");
    std::cout << std::boolalpha;
    std::cout << found.value().getContent() << "\n";
    std::cout << task->isOpen() << "\n";
    std::cout << task->getHistory().size() << "\n";
}
