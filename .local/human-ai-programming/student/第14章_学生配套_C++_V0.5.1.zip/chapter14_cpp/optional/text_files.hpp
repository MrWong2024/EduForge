#ifndef CH13_TEXT_FILES_HPP
#define CH13_TEXT_FILES_HPP
#include <filesystem>
#include <fstream>
#include <string>

namespace TextFiles {
// Provided byte-level support, not a student implementation task.
// Reject overlong sequences, surrogate encodings and values above U+10FFFF.
inline void requireUtf8(const std::string& text) {
    std::size_t i = 0;
    while (i < text.size()) {
        unsigned char first = static_cast<unsigned char>(text[i]);
        std::size_t length = 0;
        unsigned int value = 0, minimum = 0;
        if (first < 0x80) { i = i + 1; continue; }
        if (first >= 0xC2 && first <= 0xDF) {
            length = 2; value = first & 0x1F; minimum = 0x80;
        } else if (first >= 0xE0 && first <= 0xEF) {
            length = 3; value = first & 0x0F; minimum = 0x800;
        } else if (first >= 0xF0 && first <= 0xF4) {
            length = 4; value = first & 0x07; minimum = 0x10000;
        } else { throw std::ios_base::failure("不是有效的UTF-8"); }
        if (length > text.size() - i)
            throw std::ios_base::failure("UTF-8字符不完整");
        for (std::size_t j = 1; j < length; j = j + 1) {
            unsigned char next = static_cast<unsigned char>(text[i + j]);
            if ((next & 0xC0) != 0x80)
                throw std::ios_base::failure("不是有效的UTF-8");
            value = (value << 6) | (next & 0x3F);
        }
        if (value < minimum || value > 0x10FFFF
                || (value >= 0xD800 && value <= 0xDFFF))
            throw std::ios_base::failure("不是有效的UTF-8");
        i = i + length;
    }
}
// Borrows the stream for reading; does not take over closing responsibility.
inline std::string readBytes(std::istream& reader) {
    std::string text;
    char c;
    while (reader.get(c)) text.push_back(c);
    if (reader.bad() || !reader.eof())
        throw std::ios_base::failure("没有完整读到文件末尾");
    return text;
}
// Call only after the reading status has already been checked.
inline void closeChecked(std::ifstream& reader) {
    reader.clear();  // Clear normal EOF/fail flags, not an unchecked I/O failure.
    reader.close();
    if (reader.fail()) throw std::ios_base::failure("关闭读取文件失败");
}
inline std::string read(const std::filesystem::path& path) {
    std::ifstream reader(path, std::ios::binary);
    if (!reader.is_open()) throw std::ios_base::failure("无法打开文件");
    std::string text = readBytes(reader);
    closeChecked(reader);
    requireUtf8(text);
    return text;
}
}
#endif
