#ifndef CH13_SNAPSHOT_FORMAT_ERROR_HPP
#define CH13_SNAPSHOT_FORMAT_ERROR_HPP
#include <stdexcept>
#include <string>
class SnapshotFormatError : public std::runtime_error {
public:
    explicit SnapshotFormatError(const std::string& message)
        : std::runtime_error(message) {}
};
#endif
