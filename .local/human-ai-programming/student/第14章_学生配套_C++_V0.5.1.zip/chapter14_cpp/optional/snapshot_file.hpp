#ifndef CH13_SNAPSHOT_FILE_HPP
#define CH13_SNAPSHOT_FILE_HPP
#include <sstream>
#include "task_board.hpp"
#include "text_files.hpp"
#include "snapshot_format_error.hpp"

namespace SnapshotFile {
inline SnapshotFormatError problem(std::size_t line, const std::string& detail) {
    return SnapshotFormatError("第" + std::to_string(line) + "行：" + detail);
}
inline void requireText(const std::string& text, std::size_t line) {
    if (text.empty()) throw problem(line, "文字字段不能为空");
}
// Exact tabs, including a trailing empty field; no trim or Unicode normalization.
inline std::vector<std::string> splitFields(const std::string& line) {
    std::vector<std::string> fields;
    std::string field;
    for (char c : line) {
        if (c == '\t') { fields.push_back(field); field.clear(); }
        else field.push_back(c);
    }
    fields.push_back(field);
    return fields;
}
// Match the format's ordinary CR, LF, CRLF physical line endings only.
inline std::string normalizeNewlines(const std::string& text) {
    std::string result;
    for (std::size_t i = 0; i < text.size(); i = i + 1) {
        if (text[i] == '\r') {
            result.push_back('\n');
            if (i + 1 < text.size() && text[i + 1] == '\n') i = i + 1;
        } else result.push_back(text[i]);
    }
    return result;
}
inline std::shared_ptr<TaskBoard> parse(const std::string& text) {
    std::istringstream reader(normalizeNewlines(text));
    auto candidate = std::make_shared<TaskBoard>();
    std::string line;
    if (!std::getline(reader, line) || line != "TASKS-1")
        throw SnapshotFormatError("第1行应为TASKS-1");
    TaskHandle currentTask = nullptr;
    bool closeAfterRecords = false;
    std::size_t lineNumber = 1;
    while (std::getline(reader, line)) {
        lineNumber = lineNumber + 1;
        if (line == "END") {
            if (currentTask != nullptr && closeAfterRecords) currentTask->close();
            if (std::getline(reader, line))
                throw SnapshotFormatError("END之后不能再有内容");
            return candidate;
        }
        std::vector<std::string> fields = splitFields(line);
        if (fields[0] == "TASK") {
            if (fields.size() != 4) throw problem(lineNumber, "TASK行应有4个字段");
            requireText(fields[1], lineNumber);
            requireText(fields[2], lineNumber);
            if (fields[3] != "OPEN" && fields[3] != "CLOSED")
                throw problem(lineNumber, "状态只能是OPEN或CLOSED");
            if (currentTask != nullptr && closeAfterRecords) currentTask->close();
            currentTask = std::make_shared<LearningTask>(fields[1], fields[2]);
            if (!candidate->registerTask(currentTask))
                throw problem(lineNumber, "任务编号重复");
            closeAfterRecords = fields[3] == "CLOSED";
        } else if (fields[0] == "SUBMIT") {
            if (fields.size() != 3 || currentTask == nullptr)
                throw problem(lineNumber, "SUBMIT行应有3个字段且位于TASK之后");
            requireText(fields[1], lineNumber);
            requireText(fields[2], lineNumber);
            if (!currentTask->receive(SubmissionRecord(currentTask->getTaskId(),
                                                      fields[1], fields[2])))
                throw problem(lineNumber, "历史记录无法恢复");
        } else throw problem(lineNumber, "无法识别的行");
    }
    throw SnapshotFormatError("缺少END，文件可能不完整");
}
inline std::shared_ptr<TaskBoard> load(const std::filesystem::path& path) {
    std::string text = TextFiles::read(path);
    return parse(text);
}
inline void requireWritable(const std::string& text) {
    if (text.empty() || text.find_first_of("\t\n\r") != std::string::npos)
        throw SnapshotFormatError("TASKS-1文字字段不能为空或含制表符、换行");
    TextFiles::requireUtf8(text);
}
inline std::vector<std::string> toLines(const std::shared_ptr<TaskBoard>& board) {
    std::vector<std::string> lines{"TASKS-1"};
    TaskListSnapshot tasks = board->listTasks();
    for (std::size_t i = 0; i < tasks.size(); i = i + 1) {
        TaskHandle task = tasks.get(i);
        requireWritable(task->getTaskId()); requireWritable(task->getTitle());
        std::string state = task->isOpen() ? "OPEN" : "CLOSED";
        lines.push_back("TASK\t" + task->getTaskId() + "\t" + task->getTitle() + "\t" + state);
        HistorySnapshot records = task->getHistory();
        for (std::size_t j = 0; j < records.size(); j = j + 1) {
            SubmissionRecord record = records.get(j);
            requireWritable(record.getStudentId()); requireWritable(record.getContent());
            lines.push_back("SUBMIT\t" + record.getStudentId() + "\t" + record.getContent());
        }
    }
    lines.push_back("END");
    return lines;
}
inline void saveNew(const std::filesystem::path& path,
                    const std::shared_ptr<TaskBoard>& board) {
    std::vector<std::string> lines = toLines(board);
    std::ofstream writer(path, std::ios::out | std::ios::binary | std::ios::noreplace);
    if (!writer.is_open()) throw std::ios_base::failure("不能创建新文件；不覆盖已有目标");
    for (const std::string& line : lines) writer << line << '\n';
    if (!writer) throw std::ios_base::failure("写入失败");
    writer.close();
    if (writer.fail()) throw std::ios_base::failure("关闭写入文件失败");
}
}
#endif
