#ifndef CH13_TASK_SESSION_HPP
#define CH13_TASK_SESSION_HPP
#include "snapshot_file.hpp"
class TaskSession {
    std::shared_ptr<TaskBoard> current;
public:
    explicit TaskSession(std::shared_ptr<TaskBoard> initial) : current(initial) {}
    std::shared_ptr<TaskBoard> getCurrent() const { return current; }
    void restore(const std::filesystem::path& path) {
        std::shared_ptr<TaskBoard> candidate = SnapshotFile::load(path);
        current = candidate;
    }
};
#endif
